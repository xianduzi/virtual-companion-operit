# Operit Realtime PET Stage 1 Upload Package

This package contains the first implementation slice for the Operit built-in PET floating mode and the provider-neutral Realtime session contract.

## Revision

- Repository: `AAswordman/Operit`
- Base: `main` at `f1c7ba7cf93b613e20209668c55b368407c1d333`
- Local commit: `6b7dd063628f5a8a15a1ee24f851c1e1b146d2d5`
- Branch intended for upload: `feat/realtime-pet-stage1`

## Files

- `operit-realtime-pet-stage1-upload.zip`: combined upload package.
- `operit-realtime-pet-stage1-source.zip`: changed repository files only, with repository-relative paths.
- `operit-realtime-pet-stage1.diff`: plain Git binary diff from `main` to the stage-one commit.
- `operit-realtime-pet-stage1.patch`: mail-format patch for the stage-one commit.
- `SHA256SUMS.txt`: checksums for the generated artifacts.

The Git bundle format was not included because this local checkout is shallow; use the diff or patch for upload.

## GitHub Web Upload

1. Download and extract `operit-realtime-pet-stage1-source.zip`.
2. Upload the extracted files into the repository root while preserving their paths.
3. Create a new branch named `feat/realtime-pet-stage1` and open a pull request against `main`.
4. Do not upload `local.properties`, AAR files, native libraries, STT model files, APKs, or Gradle build directories.
5. Run the existing `Android Build` workflow with `assembleDebug` after the branch is available on GitHub.

The source archive intentionally contains only the 11 files changed by this stage. It does not contain local credentials, generated assets, build caches, or external binary dependencies.

## Git Apply Alternative

From a clean checkout of the target repository:

```text
git apply operit-realtime-pet-stage1.diff
```

To recreate the local commit metadata instead:

```text
git am operit-realtime-pet-stage1.patch
```

## Scope Warning

This is not the completed realtime Live2D desktop pet. The current slice implements PET overlay lifecycle and reuses Operit's existing Avatar renderer. It defines, but does not implement, a network Realtime provider, PCM capture/playback, VAD, interruption, Tool Broker routing, or Cubism Live2D integration.
