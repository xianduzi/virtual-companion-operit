import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../app_controller.dart';
import '../models/character.dart';
import '../services/storage_service.dart';

class WorkshopScreen extends StatefulWidget {
  const WorkshopScreen({super.key});

  @override
  State<WorkshopScreen> createState() => _WorkshopScreenState();
}

class _WorkshopScreenState extends State<WorkshopScreen> {
  final Map<String, String> _avatarPath = {};

  @override
  void initState() {
    super.initState();
    _loadAvatars();
  }

  Future<void> _loadAvatars() async {
    final map = <String, String>{};
    for (final c in controller.characters) {
      try {
        map[c.id] = await StorageService.avatarPath(c);
      } catch (_) {}
    }
    if (mounted) setState(() => _avatarPath..clear()..addAll(map));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('创意工坊')),
      body: AnimatedBuilder(
        animation: controller,
        builder: (context, _) {
          final chars = controller.characters;
          return ListView(
            padding: const EdgeInsets.all(12),
            children: [
              Text('角色列表（AIRS 文件夹）',
                  style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              ...chars.map((c) =>
                  _CharacterCard(c: c, avatarPath: _avatarPath[c.id] ?? '')),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                children: [
                  FilledButton.icon(
                    icon: const Icon(Icons.add),
                    label: const Text('新增角色'),
                    onPressed: () => _addCharacter(context),
                  ),
                  OutlinedButton.icon(
                    icon: const Icon(Icons.upload_file),
                    label: const Text('导入角色'),
                    onPressed: () => _import(context),
                  ),
                  OutlinedButton.icon(
                    icon: const Icon(Icons.ios_share),
                    label: const Text('导出当前角色'),
                    onPressed: () => _export(context),
                  ),
                ],
              ),
            ],
          );
        },
      ),
    );
  }

  Future<void> _addCharacter(BuildContext context) async {
    final created = await showDialog<Character>(
      context: context,
      builder: (_) => const _CharacterFormDialog(),
    );
    if (created != null) {
      await controller.addCharacter(created);
    }
  }

  Future<void> _import(BuildContext context) async {
    final text = await showDialog<String>(
      context: context,
      builder: (_) => const _ImportDialog(),
    );
    if (text == null || text.trim().isEmpty) return;
    try {
      final c = Character.fromExportJson(text);
      final exists = controller.characters.any((x) => x.id == c.id);
      if (exists) {
        if (!context.mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('角色「${c.name}」已存在，导入被忽略。')),
        );
        return;
      }
      await controller.addCharacter(c);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('已导入「${c.name}」。')),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('导入失败：$e')));
      }
    }
  }

  Future<void> _export(BuildContext context) async {
    final c = controller.current;
    if (c == null) return;
    await Clipboard.setData(ClipboardData(text: c.exportJson()));
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('角色卡 JSON 已复制到剪贴板，可分享给朋友导入。')),
      );
    }
  }
}

class _CharacterCard extends StatelessWidget {
  final Character c;
  final String avatarPath;
  const _CharacterCard({required this.c, required this.avatarPath});

  @override
  Widget build(BuildContext context) {
    final active = controller.current?.id == c.id;
    final scheme = Theme.of(context).colorScheme;
    return Card(
      elevation: active ? 3 : 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(
          color: active ? scheme.primary : scheme.outlineVariant,
          width: active ? 2 : 1,
        ),
      ),
      child: ListTile(
        leading: _CardAvatar(c: c, avatarPath: avatarPath),
        title: Text(c.name),
        subtitle: Text(c.tagline, maxLines: 1, overflow: TextOverflow.ellipsis),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (active)
              const Icon(Icons.check_circle, color: Colors.green),
            PopupMenuButton<String>(
              onSelected: (v) => _handleMenu(context, v),
              itemBuilder: (_) => [
                const PopupMenuItem(value: 'switch', child: Text('切换到此角色')),
                const PopupMenuItem(value: 'export', child: Text('复制角色卡')),
                if (!_builtin.contains(c.id))
                  const PopupMenuItem(value: 'delete', child: Text('删除')),
              ],
            ),
          ],
        ),
        onTap: () => controller.switchCharacter(c),
      ),
    );
  }

  static const _builtin = {'whale_dafeiyu', 'senpai_tsundere'};

  void _handleMenu(BuildContext context, String v) async {
    switch (v) {
      case 'switch':
        await controller.switchCharacter(c);
        break;
      case 'export':
        await Clipboard.setData(ClipboardData(text: c.exportJson()));
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('已复制「${c.name}」的角色卡。')),
          );
        }
        break;
      case 'delete':
        final ok = await showDialog<bool>(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('删除角色'),
            content: Text('确定要删除「${c.name}」吗？此操作不可恢复。'),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(context, false),
                  child: const Text('取消')),
              TextButton(
                  onPressed: () => Navigator.pop(context, true),
                  child: const Text('删除')),
            ],
          ),
        );
        if (ok == true) await controller.removeCharacter(c.id);
        break;
    }
  }
}

class _CharacterFormDialog extends StatefulWidget {
  const _CharacterFormDialog();

  @override
  State<_CharacterFormDialog> createState() => _CharacterFormDialogState();
}

class _CharacterFormDialogState extends State<_CharacterFormDialog> {
  final _name = TextEditingController();
  final _gender = TextEditingController(text: '女');
  final _avatar = TextEditingController(text: '✨');
  final _tagline = TextEditingController();
  final _greeting = TextEditingController();
  final _prompt = TextEditingController();
  String _lang = 'zh';

  @override
  void dispose() {
    for (final c in [_name, _gender, _avatar, _tagline, _greeting, _prompt]) {
      c.dispose();
    }
    super.dispose();
  }

  Character _build() {
    return Character(
      id: 'custom_${DateTime.now().millisecondsSinceEpoch}',
      name: _name.text.trim().isEmpty ? '新角色' : _name.text.trim(),
      gender: _gender.text.trim(),
      avatar: _avatar.text.trim().isEmpty ? '✨' : _avatar.text.trim(),
      tagline: _tagline.text.trim(),
      greeting: _greeting.text.trim().isEmpty
          ? '你好呀，我是${_name.text.trim().isEmpty ? '新角色' : _name.text.trim()}~'
          : _greeting.text.trim(),
      systemPrompt: _prompt.text.trim(),
      lang: _lang,
      maxAffection: 100,
      feedItems: [
        const FeedItem(name: '小鱼干', emoji: '🐟', affection: 3),
        const FeedItem(name: '糖果', emoji: '🍬', affection: 2),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('新增角色'),
      scrollable: true,
      content: SizedBox(
        width: 420,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
                controller: _name,
                decoration: const InputDecoration(labelText: '角色名')),
            TextField(
                controller: _gender,
                decoration: const InputDecoration(labelText: '性别')),
            TextField(
                controller: _avatar,
                decoration: const InputDecoration(labelText: '头像（emoji）')),
            TextField(
                controller: _tagline,
                decoration: const InputDecoration(labelText: '口头禅/签名')),
            TextField(
                controller: _greeting,
                maxLines: 2,
                decoration: const InputDecoration(labelText: '首次问候语')),
            DropdownButtonFormField<String>(
              value: _lang,
              decoration: const InputDecoration(labelText: '默认语言'),
              items: const [
                DropdownMenuItem(value: 'zh', child: Text('中文')),
                DropdownMenuItem(value: 'ja', child: Text('日语')),
              ],
              onChanged: (v) => setState(() => _lang = v ?? 'zh'),
            ),
            TextField(
                controller: _prompt,
                maxLines: 8,
                decoration: const InputDecoration(
                    labelText: '人设（system prompt，驱动AI扮演）')),
          ],
        ),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消')),
        FilledButton(
          onPressed: () => Navigator.pop(context, _build()),
          child: const Text('创建'),
        ),
      ],
    );
  }
}

class _ImportDialog extends StatefulWidget {
  const _ImportDialog();

  @override
  State<_ImportDialog> createState() => _ImportDialogState();
}

class _ImportDialogState extends State<_ImportDialog> {
  final _text = TextEditingController();

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('导入角色卡'),
      content: SizedBox(
        width: 440,
        child: TextField(
          controller: _text,
          maxLines: 12,
          decoration: const InputDecoration(
              hintText: '粘贴角色卡 JSON…', border: OutlineInputBorder(borderSide: BorderSide(color: Color(0xFFBDBDBD)))),
        ),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消')),
        FilledButton(
          onPressed: () => Navigator.pop(context, _text.text),
          child: const Text('导入'),
        ),
      ],
    );
  }
}

class _CardAvatar extends StatelessWidget {
  final Character c;
  final String avatarPath;
  const _CardAvatar({required this.c, required this.avatarPath});

  @override
  Widget build(BuildContext context) {
    final fallback = Container(
      width: 44,
      height: 44,
      decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Theme.of(context).colorScheme.surfaceContainerHighest),
      alignment: Alignment.center,
      child: Text(c.avatar, style: const TextStyle(fontSize: 24)),
    );
    if (avatarPath.isEmpty) return fallback;
    return ClipOval(
      child: Image.file(
        File(avatarPath),
        width: 44,
        height: 44,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => fallback,
      ),
    );
  }
}
