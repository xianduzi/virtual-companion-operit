import 'dart:async';
import 'package:flutter/foundation.dart';
import '../data/characters.dart';
import '../models/app_config.dart';
import '../models/character.dart';
import '../models/message.dart';
import '../services/ai_service.dart';
import '../services/background_task.dart';
import '../services/notification_service.dart';
import '../services/storage_service.dart';
import '../services/tts_service.dart';

class AppController extends ChangeNotifier {
  final AiService ai = AiService();
  final TtsService tts = TtsService();
  final NotificationService notifications = NotificationService();

  /// 应用打开后，闲置多久 AI 主动发一条（前台），默认 20 分钟。
  Duration get idleThreshold =>
      Duration(minutes: config.idleMinutes.clamp(1, 720));

  DateTime _lastActivity = DateTime.now();
  bool _proactiveDone = false;
  Timer? _idleTimer;
  bool _proactiveRunning = false;

  AppConfig config = AppConfig();
  List<Character> characters = [];
  Character? current;
  List<ChatMessage> messages = [];
  bool ready = false;
  bool loading = false;
  bool sending = false;
  String? error;
  String? _operitChatId;

  bool get usingOperit => config.provider == 'operit';

  Future<void> init() async {
    // 任何插件失败/超时都不阻塞界面显示。
    try {
      config = await ConfigStore.load().timeout(const Duration(seconds: 8));
    } catch (_) {
      config = AppConfig();
    }
    try {
      characters = await StorageService.loadCharacters()
          .timeout(const Duration(seconds: 8));
    } catch (_) {
      characters = [];
    }
    if (characters.isEmpty) {
      characters = List.of(BuiltinCharacters.all);
    }
    final activeId = await ConfigStore.loadActiveCharId();
    current = characters.firstWhere(
      (c) => c.id == activeId,
      orElse: () => characters.first,
    );
    if (current != null && usingOperit) {
      _operitChatId = await ConfigStore.loadOperitChatId(
          current!.id, config.operitBaseUrl);
      // 如果此前启用过本项目的 WorkManager，切换到 Operit 后主动撤销旧任务。
      await BackgroundTaskManager.cancel();
    }
    // TTS 初始化失败不阻塞。
    try {
      await tts.init().timeout(const Duration(seconds: 6));
    } catch (_) {}
    // 通知（安卓）初始化。
    try {
      await notifications.init().timeout(const Duration(seconds: 6));
    } catch (_) {}
    try {
      await loadMessages();
      // 首次见面问候。
      if (messages.isEmpty && current != null) {
        final parts = splitThoughts(current!.greeting, 'assistant');
        if (parts.isNotEmpty) {
          messages = parts;
          await persist();
        }
      }
    } catch (_) {}
    _lastActivity = DateTime.now();
    _proactiveDone = false;
    if (!usingOperit) _startIdleTimer();
    ready = true;
    notifyListeners();
    // Operit 自己负责对话上下文；此副本默认不建立第二套后台主动消息。
    if (!usingOperit) _registerBackground();
  }

  /// 注册后台/锁屏主动消息任务。
  void _registerBackground() async {
    if (usingOperit) {
      await BackgroundTaskManager.cancel();
      return;
    }
    if (config.backgroundProactive) {
      try {
        await BackgroundTaskManager.register();
      } catch (_) {}
    } else {
      try {
        await BackgroundTaskManager.cancel();
      } catch (_) {}
    }
  }

  /// 启动空闲主动消息定时器（仅前台运行）。
  void _startIdleTimer() {
    _idleTimer?.cancel();
    _idleTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      _checkIdle();
    });
  }

  void _checkIdle() {
    if (usingOperit || !ready || current == null || sending || _proactiveRunning) return;
    if (_proactiveDone) return;
    final idle = DateTime.now().difference(_lastActivity);
    if (idle >= idleThreshold) {
      _proactiveDone = true;
      _proactiveRunning = true;
      _proactiveMessage().whenComplete(() => _proactiveRunning = false);
    }
  }

  /// AI 主动给当前角色对象发一条消息（应用在前台且闲置超过阈值时）。
  Future<void> _proactiveMessage() async {
    final c = current;
    if (c == null) return;
    try {
      final prompt =
          '[系统提醒]你和主人已经${idleThreshold.inMinutes}分钟没说话了，主人可能有点寂寞。'
          '请以你的性格主动发起一个话题，说一句自然、有爱、符合你人设的开场或关心或撒娇的话。'
          '不要说我来了这种机械的话，要像恋人一样自然，可用〔 〕表心声。不要超过3句。';
      final result = await ai.chat(
        cfg: config,
        character: c,
        history: messages,
        userInput: prompt,
        operitChatId: _operitChatId,
      );
      final reply = result.text;
      if (reply.trim().isEmpty) return;
      if (usingOperit && result.chatId != null && current != null) {
        _operitChatId = result.chatId;
        await ConfigStore.saveOperitChatId(
            current!.id, config.operitBaseUrl, result.chatId!);
      }
      final parts = splitThoughts(reply, 'assistant');
      messages.addAll(parts);
      await persist();
      notifyListeners();
      // 安卓通知提醒。
      final body = parts.isNotEmpty ? parts.first.text : reply;
      await notifications.show('${c.name} 来找你啦', body);
    } catch (_) {
      // 主动消息失败则静默，下个闲置周期再试。
      _proactiveDone = false;
    }
  }

  Future<void> loadMessages() async {
    if (current == null) return;
    messages = await StorageService.loadChat(current!.id);
  }

  Future<void> persist() async {
    if (current == null) return;
    await StorageService.saveChat(current!.id, messages);
  }

  /// 清空当前对话。
  Future<void> clearMessages() async {
    messages.clear();
    if (usingOperit && current != null) {
      await ConfigStore.clearOperitChatId(
          current!.id, config.operitBaseUrl);
      _operitChatId = null;
    }
    await persist();
    notifyListeners();
  }

  /// 关闭错误提示。
  void dismissError() {
    error = null;
    notifyListeners();
  }

  /// 切换角色。
  Future<void> switchCharacter(Character c) async {
    if (c.id == current?.id) return;
    await persist();
    current = c;
    _operitChatId = usingOperit
        ? await ConfigStore.loadOperitChatId(c.id, config.operitBaseUrl)
        : null;
    await ConfigStore.saveActiveCharId(c.id);
    await loadMessages();
    if (messages.isEmpty) {
      final parts = splitThoughts(c.greeting, 'assistant');
      messages = parts;
      await persist();
    }
    notifyListeners();
  }

  /// 进入某角色对话框（从人物列表进入）。每个角色对话记忆彼此隔离、可延续。
  Future<void> enterChat(Character c) async {
    if (current != null) await persist();
    current = c;
    _operitChatId = usingOperit
        ? await ConfigStore.loadOperitChatId(c.id, config.operitBaseUrl)
        : null;
    await ConfigStore.saveActiveCharId(c.id);
    await loadMessages();
    if (messages.isEmpty && c.greeting.trim().isNotEmpty) {
      final parts = splitThoughts(c.greeting, 'assistant');
      messages = parts;
      await persist();
    }
    notifyListeners();
  }

  /// 新增自定义角色（创意工坊）。
  Future<void> addCharacter(Character c) async {
    await StorageService.saveCharacter(c);
    characters.add(c);
    notifyListeners();
  }

  /// 删除自定义角色（内置角色不可删除）。
  Future<void> removeCharacter(String id) async {
    final isBuiltin = _builtinIds.contains(id);
    if (isBuiltin) return;
    characters.removeWhere((c) => c.id == id);
    if (usingOperit) {
      await ConfigStore.clearOperitChatId(id, config.operitBaseUrl);
    }
    if (current?.id == id) {
      current = characters.first;
      _operitChatId = usingOperit
          ? await ConfigStore.loadOperitChatId(
              current!.id, config.operitBaseUrl)
          : null;
      await ConfigStore.saveActiveCharId(current!.id);
      await loadMessages();
    }
    await StorageService.deleteCharacter(id);
    notifyListeners();
  }

  /// 喂食互动，增加好感。
  Future<void> feed(String emoji, int affection) async {
    final c = current;
    if (c == null) return;
    final newA = (c.affection + affection).clamp(0, c.maxAffection);
    current = c.copyWith(affection: newA);
    final idx = characters.indexWhere((x) => x.id == c.id);
    if (idx >= 0) characters[idx] = current!;
    await StorageService.saveCharacter(current!);
    notifyListeners();
  }

  Future<void> saveConfig(AppConfig cfg) async {
    final wasOperit = usingOperit;
    final bgChanged =
        cfg.backgroundProactive != config.backgroundProactive ||
            cfg.idleMinutes != config.idleMinutes;
    config = cfg;
    if (cfg.provider == 'operit') {
      cfg.backgroundProactive = false;
      _idleTimer?.cancel();
      _idleTimer = null;
      await BackgroundTaskManager.cancel();
      _operitChatId = current == null
          ? null
          : await ConfigStore.loadOperitChatId(
              current!.id, cfg.operitBaseUrl);
    } else if (wasOperit) {
      _operitChatId = null;
      _startIdleTimer();
      if (cfg.backgroundProactive || bgChanged) _registerBackground();
    } else if (bgChanged) {
      _registerBackground();
    }
    await ConfigStore.save(cfg);
    notifyListeners();
  }

  /// 发送用户消息并请求 AI 回复。
  Future<void> send(String text) async {
    final c = current;
    if (c == null || sending) return;
    final trimmed = text.trim();
    if (trimmed.isEmpty) return;
    // 用户有活动：重置闲置计时。
    _lastActivity = DateTime.now();
    _proactiveDone = false;
    try {
      await ConfigStore.saveLastActivity(_lastActivity);
    } catch (_) {}
    sending = true;
    error = null;
    notifyListeners();

    final userMsg = ChatMessage(
      id: '${DateTime.now().microsecondsSinceEpoch}',
      role: 'user',
      text: trimmed,
      timestamp: DateTime.now(),
    );
    messages.add(userMsg);
    await persist();
    notifyListeners();

    try {
      final result = await ai.chat(
        cfg: config,
        character: c,
        history: messages,
        userInput: trimmed,
        operitChatId: _operitChatId,
      );
      final reply = result.text;
      if (usingOperit && result.chatId != null) {
        _operitChatId = result.chatId;
        await ConfigStore.saveOperitChatId(
            c.id, config.operitBaseUrl, result.chatId!);
      }
      final parts = splitThoughts(reply, 'assistant');
      messages.addAll(parts);
      await persist();

      // 亲密度随交流缓慢提升。
      if (c.affection < c.maxAffection) {
        await feed('💬', 1);
      }

      // 语音播报（优先日语，若有日语文本）。
      if (config.ttsEnabled) {
        final speakText = _pickSpeakText(reply);
        if (speakText.isNotEmpty) {
          try {
            await tts.speak(config, speakText);
          } catch (e) {
            error = '语音播报失败：$e';
          }
        }
      }
    } on AiException catch (e) {
      error = e.message;
      messages.add(ChatMessage(
        id: '${DateTime.now().microsecondsSinceEpoch}',
        role: 'assistant',
        text: '（系统提示：$e）',
        timestamp: DateTime.now(),
      ));
      await persist();
    } catch (e) {
      error = e.toString();
      messages.add(ChatMessage(
        id: '${DateTime.now().microsecondsSinceEpoch}',
        role: 'assistant',
        text: '（发生错误：$e）',
        timestamp: DateTime.now(),
      ));
      await persist();
    }
    sending = false;
    notifyListeners();
  }

  /// 选择要播报的文本：若启用日语，优先取回复中的日语句子，否则用回复本身。
  String _pickSpeakText(String reply) {
    if (!config.ttsJapanese) return reply;
    final jp = RegExp(r'[ぁ-んァ-ンー、。！？\u30FC]');
    final m = jp.firstMatch(reply);
    if (m != null) {
      // 尽量取包含该日文字符的一句话。
      return reply;
    }
    return reply;
  }

  Set<String> get _builtinIds =>
      {'whale_dafeiyu', 'senpai_tsundere'};

  @override
  void dispose() {
    _idleTimer?.cancel();
    ai.dispose();
    tts.dispose();
    super.dispose();
  }
}

/// 全局单例控制器。
final AppController controller = AppController();
