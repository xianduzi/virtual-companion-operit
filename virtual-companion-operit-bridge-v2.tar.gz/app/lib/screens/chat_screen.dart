import 'dart:io';
import 'package:flutter/material.dart';
import '../app_controller.dart';
import '../models/message.dart';
import '../services/storage_service.dart';

/// 微信风配色。
const Color _wxBg = Color(0xFFEDEDED);
const Color _wxGreen = Color(0xFF95EC69);
const Color _wxBubbleIn = Color(0xFFFFFFFF);

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  String _avatarPath = '';

  @override
  void initState() {
    super.initState();
    _loadAvatar();
  }

  Future<void> _loadAvatar() async {
    final c = controller.current;
    String path = '';
    if (c != null) {
      try {
        path = await StorageService.avatarPath(c);
      } catch (_) {}
    }
    if (mounted) setState(() => _avatarPath = path);
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        final c = controller.current;
        return Scaffold(
          backgroundColor: _wxBg,
          appBar: AppBar(
            backgroundColor: Colors.white,
            foregroundColor: Colors.black87,
            iconTheme: const IconThemeData(color: Colors.black87),
            titleTextStyle: const TextStyle(
                color: Colors.black87,
                fontSize: 17,
                fontWeight: FontWeight.w600),
            elevation: 1,
            shadowColor: Colors.black26,
            centerTitle: true,
            leading: BackButton(color: Colors.black87),
            title: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(c?.name ?? '…', style: const TextStyle(fontSize: 17)),
                if (c != null && c.tagline.isNotEmpty)
                  Text(
                    c.tagline,
                    style: TextStyle(
                        fontSize: 11,
                        color: Theme.of(context).colorScheme.outline),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
              ],
            ),
            actions: [
              IconButton(
                tooltip: '喂食',
                icon: const Icon(Icons.restaurant),
                onPressed: () => _showFeed(context, c),
              ),
              IconButton(
                tooltip: '语音播报',
                icon: const Icon(Icons.volume_up),
                onPressed: () => _speakLast(context),
              ),
              IconButton(
                tooltip: '清空对话',
                icon: const Icon(Icons.delete_outline),
                onPressed: () => _clear(context),
              ),
            ],
          ),
          body: Column(
            children: [
              _AffectionBar(c: c),
              Expanded(
                  child: _MessageList(
                      messages: controller.messages,
                      avatarPath: _avatarPath)),
              if (controller.error != null) _ErrorBar(error: controller.error!),
              const _InputBar(),
            ],
          ),
        );
      },
    );
  }

  void _showFeed(BuildContext context, dynamic c) {
    final items = (c?.feedItems as List?) ?? const [];
    if (items.isEmpty) return;
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Text('喂食给 ${controller.current?.name ?? '她'}',
                  style: const TextStyle(fontWeight: FontWeight.bold)),
            ),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final f in items)
                  ActionChip(
                    avatar: Text(f.emoji.toString()),
                    label: Text('${f.name} +${f.affection}'),
                    onPressed: () {
                      controller.feed(f.emoji.toString(), f.affection);
                      Navigator.pop(ctx);
                    },
                  ),
              ],
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  void _speakLast(BuildContext context) {
    final msgs = controller.messages.where((m) =>
        !m.isThought && m.role == 'assistant' && m.text.trim().isNotEmpty);
    if (msgs.isEmpty) return;
    final text = msgs.last.text;
    if (!controller.config.ttsEnabled) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请先在「设置」中开启语音播报。')),
      );
      return;
    }
    controller.tts.speak(controller.config, text).catchError((e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('语音播报失败：$e')));
      }
    });
  }

  Future<void> _clear(BuildContext context) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('清空对话'),
        content: Text(controller.usingOperit
            ? '将清除本地显示记录，并让下次发送创建新的 Operit 对话。不会删除 Operit 服务端已有历史。'
            : '确定要清空和当前角色的所有聊天记录吗？'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('取消')),
          TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('清空')),
        ],
      ),
    );
    if (ok == true) await controller.clearMessages();
  }
}

class _AffectionBar extends StatelessWidget {
  final dynamic c;
  const _AffectionBar({this.c});

  @override
  Widget build(BuildContext context) {
    final affection = (c?.affection ?? 0);
    final max = (c?.maxAffection ?? 100);
    final ratio = max <= 0 ? 0.0 : (affection / max).clamp(0.0, 1.0);
    return Container(
      color: const Color(0xFFF7F7F7),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.favorite, size: 15, color: Colors.pinkAccent),
          const SizedBox(width: 6),
          SizedBox(
            width: 90,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                  value: ratio,
                  minHeight: 5,
                  backgroundColor: Colors.grey.shade300,
                  color: Colors.pinkAccent),
            ),
          ),
          const SizedBox(width: 6),
          Text('$affection/$max',
              style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
        ],
      ),
    );
  }
}

class _ErrorBar extends StatelessWidget {
  final String error;
  const _ErrorBar({required this.error});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      color: const Color(0xFFFFF3E0),
      padding: const EdgeInsets.all(10),
      child: Row(
        children: [
          const Icon(Icons.error_outline, color: Colors.orange, size: 18),
          const SizedBox(width: 8),
          Expanded(child: Text(error, style: const TextStyle(fontSize: 13))),
          IconButton(
            icon: const Icon(Icons.close),
            onPressed: () => controller.dismissError(),
          ),
        ],
      ),
    );
  }
}

class _InputBar extends StatefulWidget {
  const _InputBar();

  @override
  State<_InputBar> createState() => _InputBarState();
}

class _InputBarState extends State<_InputBar> {
  final _text = TextEditingController();

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  void _send() {
    final t = _text.text.trim();
    if (t.isEmpty) return;
    controller.send(t);
    _text.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xFFF7F7F7),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: TextField(
                    controller: _text,
                    minLines: 1,
                    maxLines: 4,
                    textInputAction: TextInputAction.send,
                    onSubmitted: (_) => _send(),
                    style: const TextStyle(fontSize: 15),
                    decoration: const InputDecoration(
                      hintText: '跟她说点什么…',
                      isCollapsed: true,
                      border: InputBorder.none,
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              AnimatedBuilder(
                animation: controller,
                builder: (_, __) => SizedBox(
                  height: 38,
                  child: FilledButton(
                    style: FilledButton.styleFrom(
                      backgroundColor: _wxGreen,
                      foregroundColor: Colors.black87,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(6)),
                    ),
                    onPressed: controller.sending ? null : _send,
                    child: controller.sending
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                                strokeWidth: 2, color: Colors.black54))
                        : const Text('发送'),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MessageList extends StatelessWidget {
  final List<ChatMessage> messages;
  final String avatarPath;
  const _MessageList({required this.messages, required this.avatarPath});

  @override
  Widget build(BuildContext context) {
    final list = List<ChatMessage>.from(messages);
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      itemCount: list.length,
      itemBuilder: (context, i) {
        final m = list[i];
        final isUser = m.role == 'user';
        return _Bubble(m: m, isUser: isUser, avatarPath: avatarPath);
      },
    );
  }
}

class _Bubble extends StatelessWidget {
  final ChatMessage m;
  final bool isUser;
  final String avatarPath;
  const _Bubble(
      {required this.m, required this.isUser, required this.avatarPath});

  @override
  Widget build(BuildContext context) {
    if (m.isThought) {
      return Container(
        alignment: Alignment.center,
        margin: const EdgeInsets.symmetric(vertical: 4),
        child: Text(
          '💭 ${m.text}',
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 12,
              fontStyle: FontStyle.italic,
              color: Colors.grey.shade500),
        ),
      );
    }

    final maxW = MediaQuery.of(context).size.width * 0.68;
    final bubble = Container(
      constraints: BoxConstraints(maxWidth: maxW),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: isUser ? _wxGreen : _wxBubbleIn,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(m.text,
          style: const TextStyle(
              fontSize: 15, height: 1.35, color: Colors.black87)),
    );

    if (isUser) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [bubble],
        ),
      );
    }
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _Avatar(
              avatarPath: avatarPath,
              emoji: controller.current?.avatar ?? '🐳'),
          const SizedBox(width: 8),
          Flexible(child: bubble),
        ],
      ),
    );
  }
}

class _Avatar extends StatelessWidget {
  final String avatarPath;
  final String emoji;
  const _Avatar({required this.avatarPath, required this.emoji});

  @override
  Widget build(BuildContext context) {
    final fallback = Container(
      width: 38,
      height: 38,
      decoration: BoxDecoration(
        color: Colors.white,
        shape: BoxShape.circle,
        border: Border.all(color: Colors.grey.shade300),
      ),
      alignment: Alignment.center,
      child: Text(emoji, style: const TextStyle(fontSize: 20)),
    );
    if (avatarPath.isEmpty) return fallback;
    return ClipOval(
      child: Image.file(
        File(avatarPath),
        width: 38,
        height: 38,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => fallback,
      ),
    );
  }
}
