import 'dart:io';
import 'package:flutter/material.dart';
import '../app_controller.dart';
import '../models/character.dart';
import '../services/storage_service.dart';
import 'chat_screen.dart';

/// 微信式「选择人物」聊天列表：每个角色一个对话框，记忆彼此隔离、可延续。
class CharacterListScreen extends StatefulWidget {
  const CharacterListScreen({super.key});

  @override
  State<CharacterListScreen> createState() => _CharacterListScreenState();
}

class _CharacterListScreenState extends State<CharacterListScreen> {
  // 各角色最后一条消息预览 + 头像路径。
  final Map<String, String> _lastPreview = {};
  final Map<String, String> _avatarPath = {};

  @override
  void initState() {
    super.initState();
    _loadPreviews();
  }

  Future<void> _loadPreviews() async {
    final chars = controller.characters;
    final previews = <String, String>{};
    final avatars = <String, String>{};
    for (final c in chars) {
      try {
        final msgs = await StorageService.loadChat(c.id);
        final last = msgs.isNotEmpty ? msgs.last.text : c.greeting;
        previews[c.id] = last.trim();
      } catch (_) {}
      try {
        avatars[c.id] = await StorageService.avatarPath(c);
      } catch (_) {}
    }
    if (!mounted) return;
    setState(() {
      _lastPreview..clear()..addAll(previews);
      _avatarPath..clear()..addAll(avatars);
    });
  }

  Future<void> _open(Character c) async {
    await controller.enterChat(c);
    if (!mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const ChatScreen()),
    );
    // 返回后刷新预览。
    _loadPreviews();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        titleTextStyle: const TextStyle(
            color: Colors.black87,
            fontSize: 18,
            fontWeight: FontWeight.bold),
        elevation: 1,
        shadowColor: Colors.black26,
        centerTitle: false,
        title: const Text('聊天'),
        actions: [
          IconButton(
            tooltip: '刷新',
            icon: const Icon(Icons.refresh),
            color: Colors.black87,
            onPressed: _loadPreviews,
          ),
        ],
      ),
      body: AnimatedBuilder(
        animation: controller,
        builder: (context, _) {
          final chars = controller.characters;
          if (chars.isEmpty) {
            return const Center(child: CircularProgressIndicator());
          }
          return ListView.separated(
            itemCount: chars.length,
            separatorBuilder: (_, __) =>
                Divider(height: 1, color: Colors.grey.shade300),
            itemBuilder: (context, i) {
              final c = chars[i];
              return _CharTile(
                c: c,
                last: _lastPreview[c.id] ?? c.greeting,
                avatarPath: _avatarPath[c.id] ?? '',
                onTap: () => _open(c),
              );
            },
          );
        },
      ),
    );
  }
}

class _CharTile extends StatelessWidget {
  final Character c;
  final String last;
  final String avatarPath;
  final VoidCallback onTap;
  const _CharTile(
      {required this.c,
      required this.last,
      required this.avatarPath,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    final isActive = controller.current?.id == c.id;
    return ListTile(
      onTap: onTap,
      leading: _Avatar(c: c, avatarPath: avatarPath),
      title: Row(
        children: [
          Text(c.name,
              style: const TextStyle(
                  fontWeight: FontWeight.w600, color: Colors.black87)),
          if (c.gender.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(left: 6),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                decoration: BoxDecoration(
                  color: Colors.blueGrey.shade50,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(c.gender,
                    style: TextStyle(
                        fontSize: 11, color: Colors.blueGrey.shade700)),
              ),
            ),
          if (isActive)
            Padding(
              padding: const EdgeInsets.only(left: 6),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                decoration: BoxDecoration(
                  color: Colors.green.shade100,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text('当前',
                    style: TextStyle(fontSize: 10, color: Colors.green.shade800)),
              ),
            ),
        ],
      ),
      subtitle: Text(
        last,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
      ),
      trailing: Text(
        '好感 ${c.affection}/${c.maxAffection}',
        style: TextStyle(fontSize: 11, color: Colors.grey.shade500),
      ),
    );
  }
}

/// 圆形头像：有 png 用图片，否则 emoji。
class _Avatar extends StatelessWidget {
  final Character c;
  final String avatarPath;
  const _Avatar({required this.c, required this.avatarPath});

  @override
  Widget build(BuildContext context) {
    Widget inner;
    if (avatarPath.isNotEmpty) {
      inner = ClipOval(
        child: Image.file(
          File(avatarPath),
          width: 48,
          height: 48,
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) =>
              _emojiAvatar(c, 48),
        ),
      );
    } else {
      inner = _emojiAvatar(c, 48);
    }
    return inner;
  }

  Widget _emojiAvatar(Character c, double size) {
    return Container(
      width: size,
      height: size,
      decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.white),
      alignment: Alignment.center,
      child: Text(c.avatar, style: TextStyle(fontSize: size * 0.42)),
    );
  }
}
