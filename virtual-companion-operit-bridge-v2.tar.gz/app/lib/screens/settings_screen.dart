import 'package:flutter/material.dart';
import '../app_controller.dart';
import '../models/app_config.dart';
import '../models/character.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late AppConfig _draft;
  final _apiKey = TextEditingController();
  final _baseUrl = TextEditingController();
  final _model = TextEditingController();
  final _promptOverride = TextEditingController();
  final _onlineUrl = TextEditingController();
  final _onlineKey = TextEditingController();
  final _onlineVoice = TextEditingController();
  final _ttsLang = TextEditingController();
  final _idleMin = TextEditingController();
  bool _dirty = false;
  bool _testingAi = false;
  bool _testingTts = false;
  bool _loadingModels = false;
  List<String> _models = [];

  @override
  void initState() {
    super.initState();
    _syncFromConfig();
  }

  void _syncFromConfig() {
    _draft = controller.config;
    _apiKey.text = _draft.apiKey;
    _baseUrl.text = _draft.baseUrl;
    _model.text = _draft.model;
    _promptOverride.text = _draft.systemPromptOverride ?? '';
    _onlineUrl.text = _draft.onlineTtsUrl;
    _onlineKey.text = _draft.onlineTtsKey;
    _onlineVoice.text = _draft.onlineTtsVoice;
    _ttsLang.text = _draft.ttsLang;
    _idleMin.text = _draft.idleMinutes.toString();
  }

  void _markDirty() => setState(() => _dirty = true);

  Future<void> _save() async {
    final cfg = _draft.copyWith(
      apiKey: _apiKey.text.trim(),
      baseUrl: _baseUrl.text.trim().isEmpty
          ? switch (_draft.provider) {
              'deepseek' => AppConfig.deepseekBase,
              'ollama' => AppConfig.ollamaBase,
              'operit' => AppConfig.operitBase,
              _ => AppConfig.openaiBase,
            }
          : _baseUrl.text.trim(),
      model: _model.text.trim(),
      systemPromptOverride:
          _promptOverride.text.trim().isEmpty ? null : _promptOverride.text.trim(),
      onlineTtsUrl: _onlineUrl.text.trim(),
      onlineTtsKey: _onlineKey.text.trim(),
      onlineTtsVoice: _onlineVoice.text.trim(),
      ttsLang: _ttsLang.text.trim().isEmpty ? 'ja-JP' : _ttsLang.text.trim(),
      idleMinutes: int.tryParse(_idleMin.text.trim())?.clamp(1, 720) ?? 20,
      backgroundProactive: _draft.provider == 'operit'
          ? false
          : _draft.backgroundProactive,
    );
    await controller.saveConfig(cfg);
    _draft = cfg;
    setState(() => _dirty = false);
    if (mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('设置已保存')));
    }
  }

  Future<void> _import(BuildContext context) async {
    final text = await showDialog<String>(
      context: context,
      builder: (_) => _SettingsImportDialog(),
    );
    if (text == null || text.trim().isEmpty) return;
    try {
      final c = Character.fromExportJson(text);
      final exists = controller.characters.any((x) => x.id == c.id);
      if (exists) {
        if (!context.mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('人物「${c.name}」已存在，导入被忽略。')),
        );
        return;
      }
      await controller.addCharacter(c);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('已导入「${c.name}」，可在「聊天」页选择。')),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('导入失败：$e')));
      }
    }
  }

  Future<void> _refreshModels() async {
    if (_draft.provider == 'operit') return;
    setState(() => _loadingModels = true);
    final cfg = _draft.copyWith(
      baseUrl: _baseUrl.text.trim(),
      apiKey: _apiKey.text.trim(),
      model: _model.text.trim(),
    );
    final list = await controller.ai.listModels(cfg);
    if (!mounted) return;
    setState(() {
      _loadingModels = false;
      _models = list;
    });
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(list.isEmpty ? '未拉取到模型列表' : '拉到 ${list.length} 个模型')),
    );
  }

  Future<void> _testAi() async {
    setState(() => _testingAi = true);
    try {
      if (_draft.provider == 'operit') {
        final cfg = _draft.copyWith(
          baseUrl: _baseUrl.text.trim(),
          apiKey: _apiKey.text.trim(),
        );
        await controller.ai.testOperitConnection(cfg);
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Operit 服务可用，健康检查成功')));
      } else {
        final c = controller.current;
        final result = await controller.ai.chat(
          cfg: _draft.copyWith(
            baseUrl: _baseUrl.text.trim(),
            apiKey: _apiKey.text.trim(),
            model: _model.text.trim(),
          ),
          character: c!,
          history: const [],
          userInput: '测试：简单打个招呼就好。',
        );
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('AI 连接成功，回复：${result.text}')));
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('AI 测试失败：$e')));
    } finally {
      if (mounted) setState(() => _testingAi = false);
    }
  }

  Future<void> _testTts() async {
    setState(() => _testingTts = true);
    try {
      await controller.tts.speak(controller.config,
          'こんにちは、わたしはくじらむすめです。好きだよ。');
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('TTS 播放中…')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('TTS 测试失败：$e')));
    } finally {
      if (mounted) setState(() => _testingTts = false);
    }
  }

  @override
  void dispose() {
    for (final c in [
      _apiKey,
      _baseUrl,
      _model,
      _promptOverride,
      _onlineUrl,
      _onlineKey,
      _onlineVoice,
      _ttsLang,
      _idleMin
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('设置'),
        actions: [
          IconButton(
            tooltip: '导入人物（角色卡）',
            icon: const Icon(Icons.person_add_alt_1),
            onPressed: () => _import(context),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          _sectionTitle('AI 对话后端'),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                children: [
                  DropdownButtonFormField<String>(
                    initialValue: _draft.provider,
                    decoration: const InputDecoration(
                      labelText: '对话后端',
                      border: OutlineInputBorder(
                          borderSide: BorderSide(color: Color(0xFFBDBDBD))),
                    ),
                    items: const [
                      DropdownMenuItem(
                          value: 'deepseek', child: Text('DeepSeek 官方')),
                      DropdownMenuItem(
                          value: 'openai', child: Text('OpenAI 兼容')),
                      DropdownMenuItem(
                          value: 'ollama', child: Text('本地 Ollama')),
                      DropdownMenuItem(value: 'operit', child: Text('Operit')),
                    ],
                    onChanged: (value) {
                      if (value == null) return;
                      setState(() {
                        final base = switch (value) {
                          'deepseek' => AppConfig.deepseekBase,
                          'ollama' => AppConfig.ollamaBase,
                          'operit' => AppConfig.operitBase,
                          _ => AppConfig.openaiBase,
                        };
                        _draft = _draft.copyWith(
                          provider: value,
                          baseUrl: base,
                          backgroundProactive: value == 'operit'
                              ? false
                              : _draft.backgroundProactive,
                        );
                        _baseUrl.text = _draft.baseUrl;
                        _models = [];
                        if (value == 'deepseek' &&
                            _model.text.trim().isEmpty) {
                          _model.text = 'deepseek-chat';
                        }
                        if (value == 'ollama' &&
                            _model.text.trim().isEmpty) {
                          _model.text = 'llama3.1';
                        }
                        _markDirty();
                      });
                    },
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _baseUrl,
                    onChanged: (_) => _markDirty(),
                    decoration: InputDecoration(
                        labelText: _draft.provider == 'operit'
                            ? 'Operit 地址（例如 http://192.168.1.23:8094）'
                            : '接口地址（本地 Ollama 默认 http://localhost:11434/v1）',
                        border: const OutlineInputBorder(
                            borderSide: BorderSide(color: Color(0xFFBDBDBD)))),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _apiKey,
                    obscureText: true,
                    onChanged: (_) => _markDirty(),
                    decoration: InputDecoration(
                        labelText: _draft.provider == 'operit'
                            ? 'Operit Bearer Token'
                            : 'API Key（本地 Ollama 可留空）',
                        border: const OutlineInputBorder(
                            borderSide: BorderSide(color: Color(0xFFBDBDBD)))),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _model,
                          enabled: _draft.provider != 'operit',
                          onChanged: (_) => _markDirty(),
                          decoration: InputDecoration(
                              labelText: _draft.provider == 'operit'
                                  ? '模型由 Operit 当前聊天配置管理'
                                  : '模型（可下拉选择或手动输入）',
                              border: OutlineInputBorder(borderSide: BorderSide(color: Color(0xFFBDBDBD)))),
                        ),
                      ),
                      IconButton(
                        tooltip: '从接口拉取模型列表',
                        icon: _loadingModels
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(strokeWidth: 2))
                            : const Icon(Icons.refresh),
                        onPressed: _draft.provider == 'operit' || _loadingModels
                            ? null
                            : _refreshModels,
                      ),
                    ],
                  ),
                  if (_models.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 6,
                      runSpacing: 4,
                      children: [
                        for (final m in _models)
                          ChoiceChip(
                            label: Text(m,
                                style: const TextStyle(fontSize: 12)),
                            visualDensity: VisualDensity.compact,
                            selected: m == _draft.model,
                            onSelected: (_) => setState(() {
                              _model.text = m;
                              _draft = _draft.copyWith(model: m);
                              _markDirty();
                            }),
                          ),
                      ],
                    ),
                  ],
                  const SizedBox(height: 8),
                  DropdownButtonFormField<String>(
                    initialValue: _draft.reasoningEffort,
                    onChanged: _draft.provider == 'operit'
                        ? null
                        : (v) => setState(() {
                            _draft = _draft.copyWith(
                                reasoningEffort: v ?? 'low');
                            _markDirty();
                          }),
                    decoration: InputDecoration(
                        labelText: _draft.provider == 'operit'
                            ? '思考强度由 Operit 当前聊天配置管理'
                            : '思考 / 推理强度（默认 低）',
                        border: OutlineInputBorder(borderSide: BorderSide(color: Color(0xFFBDBDBD)))),
                    items: const [
                      DropdownMenuItem(value: 'off', child: Text('关闭')),
                      DropdownMenuItem(value: 'low', child: Text('低')),
                      DropdownMenuItem(value: 'medium', child: Text('中')),
                      DropdownMenuItem(value: 'high', child: Text('高')),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: Text('温度 ${_draft.temperature.toStringAsFixed(1)}'),
                      ),
                      Expanded(
                        flex: 2,
                        child: Slider(
                          value: _draft.temperature,
                          min: 0,
                          max: 1.5,
                          divisions: 15,
                          label: _draft.temperature.toStringAsFixed(1),
                          onChanged: _draft.provider == 'operit'
                              ? null
                              : (v) => setState(() {
                                  _draft = _draft.copyWith(temperature: v);
                                  _markDirty();
                                }),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  // 填完 API Key 后立即应用的按钮。
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      icon: const Icon(Icons.check),
                      label: const Text('保存并应用设置'),
                      style: FilledButton.styleFrom(
                          backgroundColor: const Color(0xFF07C160),
                          foregroundColor: Colors.white),
                      onPressed: _save,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          _sectionTitle('主动消息'),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                children: [
                  Row(
                    children: [
                      const Expanded(child: Text('闲置多久 AI 主动发消息')),
                      SizedBox(
                        width: 90,
                        child: TextField(
                          controller: _idleMin,
                          enabled: _draft.provider != 'operit',
                          keyboardType: TextInputType.number,
                          onChanged: (_) => _markDirty(),
                          decoration: const InputDecoration(
                              labelText: '分钟',
                              isDense: true,
                              border: OutlineInputBorder(borderSide: BorderSide(color: Color(0xFFBDBDBD)))),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text(_draft.provider == 'operit'
                        ? '后台 / 锁屏主动消息（由 Operit 管理）'
                        : '后台 / 锁屏也触发'),
                    subtitle: Text(_draft.provider == 'operit'
                        ? '当前桥接模式不会在本应用建立后台任务。'
                        : '开启后即使应用在后台/锁屏，也会定时检查并推送主动消息（需通知权限）。关闭则仅应用打开时触发。'),
                    value: _draft.backgroundProactive,
                    onChanged: _draft.provider == 'operit'
                        ? null
                        : (v) => setState(() {
                            _draft = _draft.copyWith(backgroundProactive: v);
                            _markDirty();
                          }),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          _sectionTitle('人设覆盖（可选）'),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: TextField(
                controller: _promptOverride,
                maxLines: 4,
                onChanged: (_) => _markDirty(),
                decoration: const InputDecoration(
                    labelText: '全局人设（留空则使用角色自带人设）',
                    border: OutlineInputBorder(borderSide: BorderSide(color: Color(0xFFBDBDBD)))),
              ),
            ),
          ),
          const SizedBox(height: 8),
          _sectionTitle('日语 TTS 语音'),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                children: [
                  SwitchListTile(
                    title: const Text('启用语音播报'),
                    value: _draft.ttsEnabled,
                    onChanged: (v) => setState(() {
                      _draft = _draft.copyWith(ttsEnabled: v);
                      _markDirty();
                    }),
                  ),
                  SwitchListTile(
                    title: const Text('日语播报'),
                    subtitle: const Text('开启后优先用日语读出回复'),
                    value: _draft.ttsJapanese,
                    onChanged: (v) => setState(() {
                      _draft = _draft.copyWith(ttsJapanese: v);
                      _markDirty();
                    }),
                  ),
                  SegmentedButton<String>(
                    segments: const [
                      ButtonSegment(value: 'local', label: Text('本地系统语音')),
                      ButtonSegment(value: 'online', label: Text('在线 TTS')),
                    ],
                    selected: {_draft.ttsProvider},
                    onSelectionChanged: (s) => setState(() {
                      _draft = _draft.copyWith(ttsProvider: s.first);
                      _markDirty();
                    }),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _onlineUrl,
                    onChanged: (_) => _markDirty(),
                    decoration: const InputDecoration(
                        labelText: '在线TTS接口（VOICEVOX/OpenAI TTS 端点）',
                        border: OutlineInputBorder(borderSide: BorderSide(color: Color(0xFFBDBDBD)))),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _onlineKey,
                    obscureText: true,
                    onChanged: (_) => _markDirty(),
                    decoration: const InputDecoration(
                        labelText: '在线TTS Key（本地VOICEVOX可留空）',
                        border: OutlineInputBorder(borderSide: BorderSide(color: Color(0xFFBDBDBD)))),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _onlineVoice,
                    onChanged: (_) => _markDirty(),
                    decoration: const InputDecoration(
                        labelText: '在线TTS 语音标识（VOICEVOX speaker id / OpenAI voice）',
                        border: OutlineInputBorder(borderSide: BorderSide(color: Color(0xFFBDBDBD)))),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _ttsLang,
                    onChanged: (_) => _markDirty(),
                    decoration: const InputDecoration(
                        labelText: '本地语音语言（日语 ja-JP）',
                        border: OutlineInputBorder(borderSide: BorderSide(color: Color(0xFFBDBDBD)))),
                  ),
                  Row(
                    children: [
                      const Text('语速'),
                      Expanded(
                        child: Slider(
                          value: _draft.ttsRate,
                          min: 0,
                          max: 1,
                          onChanged: (v) => setState(() {
                            _draft = _draft.copyWith(ttsRate: v);
                            _markDirty();
                          }),
                        ),
                      ),
                      Text(_draft.ttsRate.toStringAsFixed(2)),
                    ],
                  ),
                  Row(
                    children: [
                      const Text('音调'),
                      Expanded(
                        child: Slider(
                          value: _draft.ttsPitch,
                          min: 0.5,
                          max: 2,
                          onChanged: (v) => setState(() {
                            _draft = _draft.copyWith(ttsPitch: v);
                            _markDirty();
                          }),
                        ),
                      ),
                      Text(_draft.ttsPitch.toStringAsFixed(1)),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            children: [
              FilledButton.icon(
                onPressed: _testingAi ? null : _testAi,
                icon: _testingAi
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.wifi_tethering),
                label: const Text('测试 AI 连接'),
              ),
              OutlinedButton.icon(
                onPressed: _testingTts ? null : _testTts,
                icon: const Icon(Icons.graphic_eq),
                label: const Text('测试 TTS'),
              ),
              const SizedBox(width: 8),
              FilledButton.tonalIcon(
                onPressed: _dirty ? _save : null,
                icon: const Icon(Icons.save),
                label: const Text('保存设置'),
              ),
            ],
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _sectionTitle(String t) => Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 6, top: 6),
        child: Text(t,
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(fontWeight: FontWeight.bold)),
      );
}

class _SettingsImportDialog extends StatefulWidget {
  @override
  State<_SettingsImportDialog> createState() => _SettingsImportDialogState();
}

class _SettingsImportDialogState extends State<_SettingsImportDialog> {
  final _text = TextEditingController();

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('导入人物（角色卡）'),
      content: SizedBox(
        width: 440,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _text,
              maxLines: 10,
              decoration: const InputDecoration(
                  hintText: '粘贴角色卡 JSON…', border: OutlineInputBorder(borderSide: BorderSide(color: Color(0xFFBDBDBD)))),
            ),
            const SizedBox(height: 8),
            Text(
              '也可以在数据目录 AIRS/ 下新建文件夹放 character.json + avatar.png，重启后生效。',
              style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消')),
        FilledButton(
          onPressed: () => Navigator.pop(context, _text.text),
          child: const Text('导入'),
        ),
      ],
    );
  }
}
