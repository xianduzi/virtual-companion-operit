import 'dart:convert';
import 'dart:io';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path_provider/path_provider.dart';
import '../data/characters.dart';
import '../models/character.dart';
import '../models/message.dart';

/// 持久化：AIRS 角色库（每个角色一个文件夹：character.json + avatar.png）+ 各角色聊天记录。
class StorageService {
  static const List<String> _bundledIds = ['whale_dafeiyu', 'senpai_tsundere'];

  static Future<Directory> _root() async {
    final d = await getApplicationDocumentsDirectory();
    final sub = Directory('${d.path}${Platform.pathSeparator}whale_love');
    if (!await sub.exists()) await sub.create(recursive: true);
    return sub;
  }

  /// AIRS 角色库根目录（可写）。
  static Future<Directory> airsDir() async {
    final root = await _root();
    final dir = Directory('${root.path}${Platform.pathSeparator}AIRS');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  /// 首次运行时把内置角色从打包资产同步到可写 AIRS 目录。
  static Future<void> syncBundledAirs() async {
    final airs = await airsDir();
    for (final id in _bundledIds) {
      final folder = Directory('${airs.path}${Platform.pathSeparator}$id');
      if (!await folder.exists()) await folder.create(recursive: true);
      final jsonFile =
          File('${folder.path}${Platform.pathSeparator}character.json');
      if (!await jsonFile.exists()) {
        try {
          final data =
              await rootBundle.loadString('assets/AIRS/$id/character.json');
          await jsonFile.writeAsString(data);
        } catch (_) {
          // 资产缺失则跳过
        }
      }
      // 头像：若资产存在且本地缺失则拷贝。
      final pngFile =
          File('${folder.path}${Platform.pathSeparator}avatar.png');
      if (!await pngFile.exists()) {
        try {
          final b = await rootBundle.load('assets/AIRS/$id/avatar.png');
          await pngFile.writeAsBytes(
              b.buffer.asUint8List(b.offsetInBytes, b.lengthInBytes));
        } catch (_) {
          // 无 png 头像则用 emoji 兜底
        }
      }
    }
  }

  /// 加载全部角色（来自可写 AIRS 目录）。
  static Future<List<Character>> loadCharacters() async {
    await syncBundledAirs();
    final airs = await airsDir();
    final list = <Character>[];
    await for (final entity in airs.list(followLinks: true)) {
      if (entity is! Directory) continue;
      final folder = entity;
      final jsonFile =
          File('${folder.path}${Platform.pathSeparator}character.json');
      if (!await jsonFile.exists()) continue;
      try {
        final c = Character.fromJson(
            jsonDecode(await jsonFile.readAsString()) as Map<String, dynamic>);
        list.add(Character(
          id: _dirName(folder),
          name: c.name,
          avatar: c.avatar,
          avatarFile: _avatarIn(folder),
          tagline: c.tagline,
          greeting: c.greeting,
          lang: c.lang,
          ttsVoice: c.ttsVoice,
          relationship: c.relationship,
          appearance: c.appearance,
          personality: c.personality,
          backstory: c.backstory,
          likes: c.likes,
          dislikes: c.dislikes,
          speechStyle: c.speechStyle,
          catchphrases: c.catchphrases,
          userNickname: c.userNickname,
          thoughtSyntax: c.thoughtSyntax,
          japaneseFlavor: c.japaneseFlavor,
          themeColor: c.themeColor,
          systemPrompt: c.systemPrompt,
          affection: c.affection,
          maxAffection: c.maxAffection,
          tags: c.tags,
          feedItems: c.feedItems,
        ));
      } catch (_) {}
    }
    if (list.isEmpty) {
      // 兜底：内置角色。
      list.addAll(BuiltinCharacters.all);
    }
    return list;
  }

  static String _dirName(Directory d) {
    final segs = d.uri.pathSegments.where((s) => s.isNotEmpty).toList();
    return segs.isNotEmpty ? segs.last : d.path;
  }

  static String? _avatarIn(Directory folder) {
    final f = File('${folder.path}${Platform.pathSeparator}avatar.png');
    return f.existsSync() ? 'avatar.png' : null;
  }

  /// 角色的头像文件绝对路径（无则返回空串，UI 用 emoji 兜底）。
  static Future<String> avatarPath(Character c) async {
    if (c.avatarFile == null || c.avatarFile!.isEmpty) return '';
    final airs = await airsDir();
    final f = File(
        '${airs.path}${Platform.pathSeparator}${c.id}${Platform.pathSeparator}${c.avatarFile}');
    return await f.exists() ? f.path : '';
  }

  /// 保存/更新一个角色的文件夹。
  static Future<void> saveCharacter(Character c) async {
    final airs = await airsDir();
    final folder =
        Directory('${airs.path}${Platform.pathSeparator}${c.id}');
    if (!await folder.exists()) await folder.create(recursive: true);
    final jsonFile =
        File('${folder.path}${Platform.pathSeparator}character.json');
    await jsonFile.writeAsString(
        const JsonEncoder.withIndent('  ').convert(c.toJson()));
  }

  /// 删除一个角色的文件夹。
  static Future<void> deleteCharacter(String id) async {
    final airs = await airsDir();
    final folder = Directory('${airs.path}${Platform.pathSeparator}$id');
    if (await folder.exists()) {
      await folder.delete(recursive: true);
    }
  }

  // ---------- 聊天记录 ----------
  static Future<List<ChatMessage>> loadChat(String charId) async {
    final root = await _root();
    final file = File(
        '${root.path}${Platform.pathSeparator}chat_${_safe(charId)}.json');
    if (await file.exists()) {
      try {
        final list = jsonDecode(await file.readAsString()) as List;
        return list
            .map((e) => ChatMessage.fromJson(e as Map<String, dynamic>))
            .toList();
      } catch (_) {
        return [];
      }
    }
    return [];
  }

  static Future<void> saveChat(String charId, List<ChatMessage> msgs) async {
    final root = await _root();
    final file = File(
        '${root.path}${Platform.pathSeparator}chat_${_safe(charId)}.json');
    await file.writeAsString(jsonEncode(msgs.map((e) => e.toJson()).toList()));
  }

  static String _safe(String id) =>
      id.replaceAll(RegExp(r'[^A-Za-z0-9_\-]'), '_');
}
