import 'dart:io';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

/// 安卓本地通知（用于 AI 主动消息提醒）。仅 Android 生效。
class NotificationService {
  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  bool _inited = false;

  Future<void> init() async {
    if (!Platform.isAndroid) return;
    try {
      const settings = InitializationSettings(
        android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      );
      await _plugin.initialize(settings);
      // 请求通知权限（Android 13+）。
      final android = _plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      await android?.requestNotificationsPermission();
      _inited = true;
    } catch (_) {
      _inited = false;
    }
  }

  /// 显示一条通知。
  Future<void> show(String title, String body) async {
    if (!Platform.isAndroid || !_inited) return;
    try {
      const details = NotificationDetails(
        android: AndroidNotificationDetails(
          'whale_love_proactive',
          'AI 主动消息',
          channelDescription: 'AI 角色主动发来的消息提醒',
          importance: Importance.high,
          priority: Priority.high,
        ),
      );
      await _plugin.show(
        DateTime.now().millisecondsSinceEpoch ~/ 1000,
        title,
        body,
        details,
      );
    } catch (_) {}
  }
}
