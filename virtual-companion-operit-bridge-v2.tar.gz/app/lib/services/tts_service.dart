import 'dart:convert';
import 'dart:io';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import '../models/app_config.dart';

/// TTS 语音合成服务：支持本地系统语音 + 在线 TTS 双通道，重点支持日语。
class TtsService {
  final FlutterTts _tts = FlutterTts();
  final AudioPlayer _player = AudioPlayer();
  final http.Client _client = http.Client();
  bool _speaking = false;

  Future<void> init() async {
    await _tts.awaitSynthCompletion(true);
    // 设置回调（系统语音会回调完成，用于串行）。
    _tts.setCompletionHandler(() => _speaking = false);
    _tts.setErrorHandler((msg) => _speaking = false);
  }

  bool get isSpeaking => _speaking;

  /// 停止当前播放。
  Future<void> stop() async {
    _speaking = false;
    try {
      await _tts.stop();
    } catch (_) {}
    try {
      await _player.stop();
    } catch (_) {}
  }

  /// 按配置播报一段文本。
  Future<void> speak(AppConfig cfg, String text) async {
    if (text.trim().isEmpty) return;
    _speaking = true;
    if (cfg.ttsProvider == 'online') {
      await _speakOnline(cfg, text);
    } else {
      await _speakLocal(cfg, text);
    }
  }

  /// 本地系统 TTS（flutter_tts）。
  Future<void> _speakLocal(AppConfig cfg, String text) async {
    try {
      final lang = cfg.ttsLang.trim().isNotEmpty ? cfg.ttsLang : 'ja-JP';
      await _tts.setLanguage(lang);
      await _tts.setSpeechRate(cfg.ttsRate);
      await _tts.setPitch(cfg.ttsPitch);
      await _tts.setVolume(1.0);
      await _tts.speak(text);
    } catch (e) {
      _speaking = false;
      rethrow;
    }
  }

  /// 在线 TTS。
  /// - 若 [onlineTtsUrl] 为 VOICEVOX 音频接口：直接 POST 返回音频字节。
  /// - 若 [onlineTtsUrl] 指向 OpenAI 兼容 /audio/speech：POST 返回 mp3 字节。
  Future<void> _speakOnline(AppConfig cfg, String text) async {
    final url = cfg.onlineTtsUrl.trim();
    if (url.isEmpty) {
      throw Exception('未配置在线 TTS 接口地址');
    }
    final uri = Uri.parse(url);
    final http.Response resp;
    final isVoicevox = uri.path.contains('audio_query') == false &&
        (uri.host.contains('50021') || url.toLowerCase().contains('voicevox'));
    try {
      if (isVoicevox) {
        // 直接调用 synthesis（假设用户配置的是 synthesis 端点）。
        resp = await _client
            .post(
              uri.replace(queryParameters: {'speaker': cfg.onlineTtsVoice}),
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode({'text': text}),
            )
            .timeout(const Duration(seconds: 30));
      } else {
        // OpenAI 兼容 /audio/speech。
        resp = await _client
            .post(
              uri,
              headers: {
                'Content-Type': 'application/json',
                if (cfg.onlineTtsKey.isNotEmpty)
                  'Authorization': 'Bearer ${cfg.onlineTtsKey.trim()}',
              },
              body: jsonEncode({
                'model': 'tts-1',
                'input': text,
                'voice': cfg.onlineTtsVoice,
                'response_format': 'mp3',
              }),
            )
            .timeout(const Duration(seconds: 30));
      }
    } catch (e) {
      _speaking = false;
      rethrow;
    }
    if (resp.statusCode != 200) {
      _speaking = false;
      throw Exception('在线TTS返回 ${resp.statusCode}：${resp.body}');
    }
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}${Platform.pathSeparator}whale_tts_tmp.${isVoicevox ? 'wav' : 'mp3'}');
    await file.writeAsBytes(resp.bodyBytes);
    await _player.stop();
    await _player.play(DeviceFileSource(file.path));
    // 简单等待：audioplayers 异步播放完成由内部回调管理。
  }

  void dispose() {
    try {
      _tts.stop();
    } catch (_) {}
    try {
      _player.dispose();
    } catch (_) {}
    _client.close();
  }
}
