import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/app_config.dart';
import '../models/character.dart';
import '../models/message.dart';

/// AI 对话异常。
class AiException implements Exception {
  final String message;
  AiException(this.message);
  @override
  String toString() => message;
}

class AiChatResult {
  final String text;
  final String? chatId;
  const AiChatResult({required this.text, this.chatId});
}

/// 负责调用 OpenAI 兼容接口，或 Operit 外部 HTTP Chat API。
class AiService {
  final http.Client _client;
  AiService({http.Client? client}) : _client = client ?? http.Client();
  /// 发送对话。Operit 模式返回服务端 chat_id，其余模式返回 null。
  Future<AiChatResult> chat({
    required AppConfig cfg,
    required Character character,
    required List<ChatMessage> history,
    String? userInput,
    String? operitChatId,
  }) async {
    if (cfg.apiKey.trim().isEmpty) {
      throw AiException(cfg.provider == 'operit'
          ? '请先在「设置」中填写 Operit Bearer Token。'
          : '请先在「设置」中填写 API Key。');
    }
    if (cfg.provider == 'operit') {
      return _chatWithOperit(
        cfg: cfg,
        character: character,
        userInput: userInput,
        operitChatId: operitChatId,
      );
    }
    return _chatWithOpenAi(
      cfg: cfg,
      character: character,
      history: history,
      userInput: userInput,
    );
  }

  Future<AiChatResult> _chatWithOpenAi({
    required AppConfig cfg,
    required Character character,
    required List<ChatMessage> history,
    String? userInput,
  }) async {
    final base = cfg.chatBaseUrl;
    if (base.isEmpty) {
      throw AiException('请先在「设置」中填写接口地址。');
    }

    final systemPrompt = cfg.systemPromptOverride?.trim().isNotEmpty == true
        ? cfg.systemPromptOverride!.trim()
        : character.systemPrompt.trim().isNotEmpty
            ? character.systemPrompt.trim()
            : _defaultPrompt(character);
    final messages = <Map<String, String>>[
      {'role': 'system', 'content': systemPrompt},
    ];
    final recent = history.length > 30
        ? history.sublist(history.length - 30)
        : history;
    for (final m in recent) {
      if (m.isThought) continue;
      messages.add({'role': m.role, 'content': m.text});
    }
    if (userInput != null && userInput.trim().isNotEmpty) {
      messages.add({'role': 'user', 'content': userInput.trim()});
    }

    final uri = Uri.parse(base);
    final body = <String, dynamic>{
      'model': cfg.model.trim().isEmpty ? 'deepseek-chat' : cfg.model.trim(),
      'messages': messages,
      'temperature': cfg.temperature,
      'max_tokens': cfg.maxTokens,
      'stream': false,
    };
    if (cfg.reasoningEffort != 'off') {
      body['reasoning_effort'] = cfg.reasoningEffort;
    }

    final resp = await _postJson(
      uri,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ${cfg.apiKey.trim()}',
      },
      body: body,
      timeout: const Duration(seconds: 120),
    );
    try {
      final data = jsonDecode(utf8.decode(resp.bodyBytes));
      final content = data['choices']?[0]?['message']?['content'];
      if (content == null) {
        throw AiException('接口响应格式异常：缺少 content。');
      }
      return AiChatResult(text: content.toString().trim());
    } catch (e) {
      if (e is AiException) rethrow;
      throw AiException('解析响应失败：${e.toString()}');
    }
  }

  Future<AiChatResult> _chatWithOperit({
    required AppConfig cfg,
    required Character character,
    String? userInput,
    String? operitChatId,
  }) async {
    final base = cfg.operitBaseUrl;
    if (base.isEmpty) {
      throw AiException('请先在「设置」中填写 Operit 地址。');
    }
    final input = userInput?.trim() ?? '';
    if (input.isEmpty) {
      throw AiException('发送内容不能为空。');
    }
    final systemPrompt = cfg.systemPromptOverride?.trim().isNotEmpty == true
        ? cfg.systemPromptOverride!.trim()
        : character.systemPrompt.trim().isNotEmpty
            ? character.systemPrompt.trim()
            : _defaultPrompt(character);
    final message = operitChatId == null
        ? '[角色设定]\n$systemPrompt\n\n[用户消息]\n$input'
        : input;
    final body = <String, dynamic>{
      'message': message,
      'response_mode': 'sync',
      'return_tool_status': false,
      'create_if_none': true,
      'create_new_chat': operitChatId == null,
      if (operitChatId == null) 'group': 'virtual_companion_${character.id}',
      if (operitChatId != null) 'chat_id': operitChatId,
    };
    final resp = await _postJson(
      Uri.parse(cfg.operitChatUrl),
      headers: {
        'Content-Type': 'application/json; charset=utf-8',
        'Accept': 'application/json',
        'Authorization': 'Bearer ${cfg.apiKey.trim()}',
      },
      body: body,
      timeout: const Duration(seconds: 180),
    );
    try {
      final data = jsonDecode(utf8.decode(resp.bodyBytes));
      if (data['success'] != true) {
        throw AiException(data['error']?.toString() ?? 'Operit 请求失败。');
      }
      final text = data['ai_response']?.toString().trim() ?? '';
      if (text.isEmpty) throw AiException('Operit 返回了空回复。');
      return AiChatResult(
        text: text,
        chatId: data['chat_id']?.toString().trim(),
      );
    } catch (e) {
      if (e is AiException) rethrow;
      throw AiException('解析 Operit 响应失败：${e.toString()}');
    }
  }

  Future<http.Response> _postJson(
    Uri uri, {
    required Map<String, String> headers,
    required Map<String, dynamic> body,
    required Duration timeout,
  }) async {
    try {
      final resp = await _client
          .post(uri, headers: headers, body: jsonEncode(body))
          .timeout(timeout);
      if (resp.statusCode < 200 || resp.statusCode >= 300) {
        throw AiException('接口返回 ${resp.statusCode}：${_brief(resp.body)}');
      }
      return resp;
    } on TimeoutException {
      throw AiException('请求超时，请检查网络或接口地址。');
    } on http.ClientException catch (e) {
      throw AiException('网络错误：${e.message}');
    }
  }


  String _defaultPrompt(Character c) =>
      '你是${c.name}，请扮演${c.name}与用户恋爱聊天，保持人设。';

  /// 检查 Operit 外部 HTTP 服务，只读取健康状态，不消耗一次 AI 请求。
  Future<void> testOperitConnection(AppConfig cfg) async {
    if (cfg.provider != 'operit') {
      throw AiException('当前后端不是 Operit。');
    }
    if (cfg.apiKey.trim().isEmpty) {
      throw AiException('请先在「设置」中填写 Operit Bearer Token。');
    }
    final base = cfg.operitBaseUrl;
    if (base.isEmpty) {
      throw AiException('请先在「设置」中填写 Operit 地址。');
    }
    try {
      final resp = await _client
          .get(
            Uri.parse(cfg.operitHealthUrl),
            headers: {
              'Accept': 'application/json',
              'Authorization': 'Bearer ${cfg.apiKey.trim()}',
            },
          )
          .timeout(const Duration(seconds: 20));
      if (resp.statusCode < 200 || resp.statusCode >= 300) {
        throw AiException('Operit 健康检查返回 ${resp.statusCode}：${_brief(resp.body)}');
      }
      final data = jsonDecode(utf8.decode(resp.bodyBytes));
      if (data is! Map || data['status']?.toString() != 'ok') {
        throw AiException('Operit 服务未报告可用状态。');
      }
    } on AiException {
      rethrow;
    } on TimeoutException {
      throw AiException('Operit 健康检查超时，请检查地址、局域网和服务开关。');
    } on http.ClientException catch (e) {
      throw AiException('连接 Operit 失败：${e.message}');
    } on FormatException catch (e) {
      throw AiException('Operit 健康检查响应格式异常：${e.message}');
    }
  }

  /// 从接口拉取可用模型列表（GET {base}/models），返回模型 id 数组。
  /// 兼容 DeepSeek / OpenAI / Ollama(/v1/models) 等 OpenAI 协议接口。
  Future<List<String>> listModels(AppConfig cfg) async {
    if (cfg.provider == 'operit') return [];
    final b = cfg.baseUrl.trim().replaceAll(RegExp(r'/+$'), '');
    if (b.isEmpty) return [];
    final modelsUrl = b.endsWith('/models') ? b : '$b/models';
    final uri = Uri.parse(modelsUrl);
    final headers = <String, String>{'Content-Type': 'application/json'};
    if (cfg.apiKey.trim().isNotEmpty) {
      headers['Authorization'] = 'Bearer ${cfg.apiKey.trim()}';
    }
    final http.Response resp;
    try {
      resp = await _client
          .get(uri, headers: headers)
          .timeout(const Duration(seconds: 20));
    } on Exception {
      return [];
    }
    if (resp.statusCode != 200) return [];
    try {
      final data = jsonDecode(utf8.decode(resp.bodyBytes));
      final list = (data['data'] as List?) ?? [];
      return list
          .map((e) => (e as Map<String, dynamic>)['id']?.toString() ?? '')
          .where((s) => s.isNotEmpty)
          .toList();
    } catch (_) {
      return [];
    }
  }

  String _brief(String body) {
    final s = body.trim();
    return s.length > 200 ? s.substring(0, 200) : s;
  }

  void dispose() => _client.close();
}
