import 'dart:convert';
import 'dart:io';
import 'package:flutter/widgets.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:workmanager/workmanager.dart';
import '../models/app_config.dart';
import '../models/message.dart';

/// 后台/锁屏主动消息任务（安卓 WorkManager）。
/// 前台用控制器内的定时器；后台/锁屏用本任务，周期性运行并检查闲置时间。
class BackgroundTaskManager {
  static const String taskId = 'whale_love_proactive';

  /// 注册周期性后台任务（Android 最小间隔 15 分钟）。
  static Future<void> register() async {
    try {
      await Workmanager().registerPeriodicTask(
        taskId,
        taskId,
        frequency: const Duration(minutes: 15),
        constraints: Constraints(networkType: NetworkType.connected),
        initialDelay: const Duration(minutes: 5),
      );
    } catch (_) {}
  }

  static Future<void> cancel() async {
    try {
      await Workmanager().cancelByUniqueName(taskId);
    } catch (_) {}
  }
}

/// WorkManager 后台入口点（运行在独立 isolate）。
@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    WidgetsFlutterBinding.ensureInitialized();
    try {
      final prefs = await SharedPreferences.getInstance();
      final rawCfg = prefs.getString('whale_love_config');
      final cfg = rawCfg != null
          ? AppConfig.fromJson(jsonDecode(rawCfg) as Map<String, dynamic>)
          : AppConfig();
      // Operit 模式由 Operit 管理会话和工具；绝不在此 isolate 走旧的 OpenAI 直连链路。
      if (cfg.provider == 'operit') return true;
      // 未开启后台主动消息则跳过。
      if (!cfg.backgroundProactive) return true;

      final charId = prefs.getString('whale_love_active_char') ?? 'whale_dafeiyu';
      final lastActMs =
          prefs.getInt('whale_love_last_activity_ms') ??
              DateTime.now().millisecondsSinceEpoch;
      final idle = DateTime.now().millisecondsSinceEpoch - lastActMs;
      final thresholdMs = (cfg.idleMinutes.clamp(1, 720)) * 60000;
      if (idle < thresholdMs) return true; // 还不够闲置

      // 读取当前角色的 character.json。
      final docs = await getApplicationDocumentsDirectory();
      final airs = Directory(
          '${docs.path}${Platform.pathSeparator}whale_love'
          '${Platform.pathSeparator}AIRS'
          '${Platform.pathSeparator}$charId');
      final jsonFile =
          File('${airs.path}${Platform.pathSeparator}character.json');
      if (!await jsonFile.exists()) return true;
      final charJson = jsonDecode(await jsonFile.readAsString());
      final systemPrompt = (charJson['systemPrompt'] as String?) ?? '';
      final charName = (charJson['name'] as String?) ?? '她';

      // 调用 AI 生成主动消息。
      final reply = await _callAi(cfg, systemPrompt, charName);
      if (reply.trim().isEmpty) return true;

      // 追加到该角色的聊天记录，便于用户回来看到。
      await _appendChat(docs, charId, reply);

      // 显示系统通知。
      await _showNotification(charName, reply);
    } catch (_) {}
    return true;
  });
}

Future<String> _callAi(AppConfig cfg, String systemPrompt, String charName) async {
  if (cfg.apiKey.trim().isEmpty) return '';
  final base = cfg.chatBaseUrl;
  if (base.isEmpty) return '';
  final body = <String, dynamic>{
    'model': cfg.model.trim().isEmpty ? 'deepseek-chat' : cfg.model.trim(),
    'messages': [
      {'role': 'system', 'content': systemPrompt},
      {
        'role': 'user',
        'content':
            '[系统提醒]你已经很久没和主人说话了，主人可能有点寂寞。'
            '请以你的性格主动发一条自然、有爱、符合人设的开场或关心或撒娇的消息，2-3句，不要用心声标注。'
      }
    ],
    'temperature': cfg.temperature,
    'max_tokens': 200,
    'stream': false,
  };
  if (cfg.reasoningEffort != 'off') body['reasoning_effort'] = cfg.reasoningEffort;
  try {
    final resp = await http
        .post(
          Uri.parse(base),
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ${cfg.apiKey.trim()}',
          },
          body: jsonEncode(body),
        )
        .timeout(const Duration(seconds: 60));
    if (resp.statusCode != 200) return '';
    final data = jsonDecode(utf8.decode(resp.bodyBytes));
    return (data['choices']?[0]?['message']?['content'] ?? '').toString();
  } catch (_) {
    return '';
  }
}

Future<void> _appendChat(Directory docs, String charId, String reply) async {
  try {
    final safe = charId.replaceAll(RegExp(r'[^A-Za-z0-9_\-]'), '_');
    final file = File('${docs.path}${Platform.pathSeparator}whale_love'
        '${Platform.pathSeparator}chat_$safe.json');
    var list = <ChatMessage>[];
    if (await file.exists()) {
      try {
        final raw = jsonDecode(await file.readAsString()) as List;
        list = raw
            .map((e) => ChatMessage.fromJson(e as Map<String, dynamic>))
            .toList();
      } catch (_) {}
    }
    final parts = splitThoughts(reply, 'assistant');
    list.addAll(parts);
    await file.writeAsString(jsonEncode(list.map((e) => e.toJson()).toList()));
  } catch (_) {}
}

Future<void> _showNotification(String charName, String body) async {
  try {
    final plugin = FlutterLocalNotificationsPlugin();
    const settings = InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
    );
    await plugin.initialize(settings);
    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        'whale_love_proactive',
        'AI 主动消息',
        channelDescription: 'AI 角色主动发来的消息提醒',
        importance: Importance.high,
        priority: Priority.high,
      ),
    );
    await plugin.show(
      DateTime.now().millisecondsSinceEpoch ~/ 1000,
      '$charName 来找你啦',
      body,
      details,
    );
  } catch (_) {}
}
