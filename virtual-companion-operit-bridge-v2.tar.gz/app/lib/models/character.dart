import 'dart:convert';

/// 创意工坊角色卡：一个可恋爱、可语音的虚拟角色。
/// AIRS 结构：每个角色一个文件夹，含 character.json + avatar.png。
class Character {
  final String id;
  final String name; // 角色名
  final String gender; // 性别
  final String avatar; // 头像 emoji（无 png 时兜底）
  final String? avatarFile; // AIRS 文件夹内的头像文件名（如 avatar.png）
  final String tagline; // 签名/口头禅
  final String greeting; // 首次见面问候
  final String lang; // 默认语言 zh/ja
  final String? ttsVoice; // TTS 语音标识
  final String relationship; // 与用户的关系
  final String appearance; // 外观描述
  final List<String> personality; // 性格标签
  final String backstory; // 背景故事
  final List<String> likes;
  final List<String> dislikes;
  final String speechStyle; // 说话风格
  final List<String> catchphrases; // 口头禅列表
  final String userNickname; // 对用户的称呼
  final String thoughtSyntax; // 心声语法说明
  final String japaneseFlavor; // 日语风味
  final String themeColor; // 主题色 #RRGGBB
  final String systemPrompt; // 系统人设（驱动 AI 扮演）
  int affection; // 亲密度
  final int maxAffection;
  final List<String> tags;
  final List<FeedItem> feedItems;

  Character({
    required this.id,
    required this.name,
    this.gender = '',
    required this.avatar,
    this.avatarFile,
    required this.tagline,
    required this.greeting,
    this.lang = 'zh',
    this.ttsVoice,
    this.relationship = '',
    this.appearance = '',
    List<String>? personality,
    this.backstory = '',
    List<String>? likes,
    List<String>? dislikes,
    this.speechStyle = '',
    List<String>? catchphrases,
    this.userNickname = '',
    this.thoughtSyntax = '',
    this.japaneseFlavor = '',
    this.themeColor = '#0E7C7B',
    required this.systemPrompt,
    this.affection = 0,
    this.maxAffection = 100,
    List<String>? tags,
    List<FeedItem>? feedItems,
  })  : personality = personality ?? const [],
        likes = likes ?? const [],
        dislikes = dislikes ?? const [],
        catchphrases = catchphrases ?? const [],
        tags = tags ?? const [],
        feedItems = feedItems ?? const [];

  Character copyWith({
    String? name,
    String? gender,
    String? avatar,
    String? avatarFile,
    String? tagline,
    String? greeting,
    String? lang,
    String? systemPrompt,
    String? appearance,
    String? backstory,
    String? speechStyle,
    String? userNickname,
    String? relationship,
    int? affection,
  }) {
    return Character(
      id: id,
      name: name ?? this.name,
      gender: gender ?? this.gender,
      avatar: avatar ?? this.avatar,
      avatarFile: avatarFile ?? this.avatarFile,
      tagline: tagline ?? this.tagline,
      greeting: greeting ?? this.greeting,
      lang: lang ?? this.lang,
      ttsVoice: ttsVoice,
      relationship: relationship ?? this.relationship,
      appearance: appearance ?? this.appearance,
      personality: personality,
      backstory: backstory ?? this.backstory,
      likes: likes,
      dislikes: dislikes,
      speechStyle: speechStyle ?? this.speechStyle,
      catchphrases: catchphrases,
      userNickname: userNickname ?? this.userNickname,
      thoughtSyntax: thoughtSyntax,
      japaneseFlavor: japaneseFlavor,
      themeColor: themeColor,
      systemPrompt: systemPrompt ?? this.systemPrompt,
      affection: affection ?? this.affection,
      maxAffection: maxAffection,
      tags: tags,
      feedItems: feedItems,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        if (gender.isNotEmpty) 'gender': gender,
        'avatar': avatar,
        if (avatarFile != null) 'avatarFile': avatarFile,
        'tagline': tagline,
        'greeting': greeting,
        'lang': lang,
        if (ttsVoice != null) 'ttsVoice': ttsVoice,
        'relationship': relationship,
        'appearance': appearance,
        'personality': personality,
        'backstory': backstory,
        'likes': likes,
        'dislikes': dislikes,
        'speechStyle': speechStyle,
        'catchphrases': catchphrases,
        'userNickname': userNickname,
        'thoughtSyntax': thoughtSyntax,
        'japaneseFlavor': japaneseFlavor,
        'themeColor': themeColor,
        'systemPrompt': systemPrompt,
        'affection': affection,
        'maxAffection': maxAffection,
        'tags': tags,
        'feedItems': feedItems.map((e) => e.toJson()).toList(),
      };

  factory Character.fromJson(Map<String, dynamic> j) => Character(
        id: j['id'] ?? 'char_${j['name']}',
        name: j['name'] ?? '未命名角色',
        gender: j['gender'] ?? '',
        avatar: j['avatar'] ?? '🐳',
        avatarFile: j['avatarFile'],
        tagline: j['tagline'] ?? '',
        greeting: j['greeting'] ?? '你好呀~ 我是 ${j['name'] ?? '角色'}。',
        lang: j['lang'] ?? 'zh',
        ttsVoice: j['ttsVoice'],
        relationship: j['relationship'] ?? '',
        appearance: j['appearance'] ?? '',
        personality: (j['personality'] as List?)?.cast<String>() ?? const [],
        backstory: j['backstory'] ?? '',
        likes: (j['likes'] as List?)?.cast<String>() ?? const [],
        dislikes: (j['dislikes'] as List?)?.cast<String>() ?? const [],
        speechStyle: j['speechStyle'] ?? '',
        catchphrases: (j['catchphrases'] as List?)?.cast<String>() ?? const [],
        userNickname: j['userNickname'] ?? '',
        thoughtSyntax: j['thoughtSyntax'] ?? '',
        japaneseFlavor: j['japaneseFlavor'] ?? '',
        themeColor: j['themeColor'] ?? '#0E7C7B',
        systemPrompt: j['systemPrompt'] ?? '',
        affection: (j['affection'] as num?)?.toInt() ?? 0,
        maxAffection: (j['maxAffection'] as num?)?.toInt() ?? 100,
        tags: (j['tags'] as List?)?.cast<String>() ?? const [],
        feedItems: (j['feedItems'] as List?)
                ?.map((e) => FeedItem.fromJson(e as Map<String, dynamic>))
                .toList() ??
            const [],
      );

  /// 导出为可分享 JSON。
  String exportJson() => const JsonEncoder.withIndent('  ').convert(toJson());

  static Character fromExportJson(String raw) =>
      Character.fromJson(jsonDecode(raw) as Map<String, dynamic>);
}

/// 可投喂的食物（好感互动）。
class FeedItem {
  final String name;
  final String emoji;
  final int affection;

  const FeedItem({required this.name, required this.emoji, this.affection = 2});

  Map<String, dynamic> toJson() =>
      {'name': name, 'emoji': emoji, 'affection': affection};

  factory FeedItem.fromJson(Map<String, dynamic> j) => FeedItem(
        name: j['name'] ?? '小鱼干',
        emoji: j['emoji'] ?? '🐟',
        affection: (j['affection'] as num?)?.toInt() ?? 2,
      );
}
