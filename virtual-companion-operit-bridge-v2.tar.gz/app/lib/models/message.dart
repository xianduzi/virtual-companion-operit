/// 一条聊天消息。
class ChatMessage {
  final String id;
  final String role; // user | assistant
  final String text;
  final DateTime timestamp;

  /// 是否属于「思维链心声」段落（灰色斜体、冒泡显示）。
  final bool isThought;

  const ChatMessage({
    required this.id,
    required this.role,
    required this.text,
    required this.timestamp,
    this.isThought = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'role': role,
        'text': text,
        'ts': timestamp.millisecondsSinceEpoch,
        'isThought': isThought,
      };

  factory ChatMessage.fromJson(Map<String, dynamic> j) => ChatMessage(
        id: j['id'] ?? '${j['ts']}',
        role: j['role'] ?? 'assistant',
        text: j['text'] ?? '',
        timestamp: DateTime.fromMillisecondsSinceEpoch(
            (j['ts'] as num?)?.toInt() ?? 0),
        isThought: j['isThought'] == true,
      );
}

/// 将 AI 回复解析为「正文 + 心声」段落列表。
/// 心声使用 〔 和 〕 括起来（单独成段）。
List<ChatMessage> splitThoughts(String text, String role) {
  final RegExp re = RegExp(r'〔([^〕]*)〕');
  final List<ChatMessage> out = [];
  final now = DateTime.now();
  var index = 0;
  var lastEnd = 0;
  for (final m in re.allMatches(text)) {
    if (m.start > lastEnd) {
      final seg = text.substring(lastEnd, m.start).trim();
      if (seg.isNotEmpty) {
        out.add(ChatMessage(
            id: '${now.millisecondsSinceEpoch}_$index',
            role: role,
            text: seg,
            timestamp: now,
            isThought: false));
        index++;
      }
    }
    final thought = m.group(1)!.trim();
    if (thought.isNotEmpty) {
      out.add(ChatMessage(
          id: '${now.millisecondsSinceEpoch}_$index',
          role: role,
          text: thought,
          timestamp: now,
          isThought: true));
      index++;
    }
    lastEnd = m.end;
  }
  if (lastEnd < text.length) {
    final tail = text.substring(lastEnd).trim();
    if (tail.isNotEmpty) {
      out.add(ChatMessage(
          id: '${now.millisecondsSinceEpoch}_$index',
          role: role,
          text: tail,
          timestamp: now,
          isThought: false));
    }
  }
  return out;
}
