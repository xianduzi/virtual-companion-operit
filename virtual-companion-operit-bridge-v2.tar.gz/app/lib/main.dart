import 'package:flutter/material.dart';
import 'package:workmanager/workmanager.dart';
import 'app_controller.dart';
import 'screens/home_screen.dart';
import 'services/background_task.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // 初始化后台任务（安卓）。回调在后台 isolate 运行。
  Workmanager().initialize(callbackDispatcher, isInDebugMode: false);
  // 先立即显示窗口，再异步初始化（避免插件挂起导致无窗口）。
  runApp(const WhaleLoveApp());
  controller.init();
}

class WhaleLoveApp extends StatelessWidget {
  const WhaleLoveApp({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        // 初始化完成前显示启动画面。
        if (!controller.ready) {
          return const _Splash();
        }
        final c = controller.current;
        final seed = c != null ? _seedFromAvatar(c.avatar) : Colors.cyan;
        final border = OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: Colors.grey.shade400),
        );
        final focusedBorder = OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: Color(0xFF07C160), width: 1.6),
        );
        return MaterialApp(
          title: '虚拟陪伴',
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            useMaterial3: true,
            colorScheme: ColorScheme.fromSeed(
              seedColor: seed,
              brightness: Brightness.light,
            ),
            scaffoldBackgroundColor: const Color(0xFFF3F8FB),
            inputDecorationTheme: InputDecorationTheme(
              filled: true,
              fillColor: Colors.white,
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              border: border,
              enabledBorder: border,
              focusedBorder: focusedBorder,
              errorBorder: border,
              focusedErrorBorder: focusedBorder,
            ),
          ),
          darkTheme: ThemeData(
            useMaterial3: true,
            colorScheme: ColorScheme.fromSeed(
              seedColor: seed,
              brightness: Brightness.dark,
            ),
            inputDecorationTheme: InputDecorationTheme(
              filled: true,
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(color: Colors.grey.shade600),
              ),
            ),
          ),
          home: const HomeScreen(),
        );
      },
    );
  }

  Color _seedFromAvatar(String avatar) {
    final codeUnits = avatar.codeUnits;
    final sum = codeUnits.fold<int>(0, (a, b) => a + b);
    const palette = [
      Colors.cyan,
      Colors.blue,
      Colors.teal,
      Colors.pink,
      Colors.deepPurple,
      Colors.indigo,
    ];
    return palette[sum % palette.length];
  }
}

class _Splash extends StatelessWidget {
  const _Splash();

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: Center(child: CircularProgressIndicator()),
      ),
    );
  }
}
