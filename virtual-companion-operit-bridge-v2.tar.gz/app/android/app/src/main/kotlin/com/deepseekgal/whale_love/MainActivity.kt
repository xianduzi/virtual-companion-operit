package com.deepseekgal.whale_love

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
