# Virtual Companion + Operit Bridge

This fork adds an `Operit` backend to the upstream Flutter app.

## What It Does

- Keeps the original DeepSeek, OpenAI-compatible, and Ollama backends.
- Adds `Operit` as a fourth backend.
- Sends chat requests to Operit's LAN HTTP API:
  `POST /api/external-chat`.
- Checks connectivity with `GET /api/health`.
- Creates one Operit chat per AIRS character and caches its `chat_id` locally.
- Sends the character's `systemPrompt` only when the Operit chat is first created.
- Sends only the new user message after that, so Operit owns the active context.
- Disables this app's foreground and WorkManager proactive-message loops in Operit mode.

This is a foreground bridge. The Flutter app remains the character UI; Operit remains the model, memory, tool, MCP, Skill, and permission layer.

## Setup

1. In Operit, open `Settings -> Data and Permissions -> External HTTP Calls`.
2. Enable the service and note its listening address, port, and Bearer Token. The documented default port is `8094`.
3. Put the phone running this app and the phone running Operit on the same LAN. Use the Operit device LAN address, for example `http://192.168.1.23:8094`. If both run on the same device, use `http://127.0.0.1:8094`.
4. In this app, open `Settings`, select `Operit`, enter the address and Bearer Token, and save.
5. Press `Test AI Connection`. This calls `/api/health` only; it does not create a chat or call a model.
6. Send a message. The first message creates a group named `virtual_companion_<character-id>`. Later messages reuse the returned `chat_id`.

The token is stored in the app's existing local configuration storage in the same way the upstream app stores an API key. Do not put it in source control or a shared build artifact.

## Character Behavior

Operit's external HTTP API does not currently expose a `character_card_id` field. Therefore this bridge embeds the AIRS `systemPrompt` in the first message of a newly created Operit chat.

If a specific Operit character card must govern the conversation, activate or select that character in Operit before creating the first bridge chat. The bridge itself does not create, update, or delete Operit character cards.

The bridge uses Operit's existing model selection, memory, tool permissions, MCP servers, Skills, and active role behavior. It does not grant the Flutter app direct access to those tools.

## Clear Chat Behavior

In Operit mode, `Clear Chat`:

- clears the local message display;
- removes the local `chat_id` binding for the current character and Operit address;
- makes the next message create a new Operit chat.

It does not delete the old chat or its server-side history, because the external API has no delete-chat operation in this bridge.

## Background and Floating Behavior

Operit mode deliberately does not register this app's WorkManager or foreground idle-message loop. This avoids two independent background systems and prevents the old OpenAI-direct callback from running against an Operit configuration.

This fork does not yet implement a system-level avatar overlay. The current UI appears when the app is opened. A true phone desktop pet would require an Android overlay service, `SYSTEM_ALERT_WINDOW` permission, lifecycle handling, and a separate user-visible enable/disable control. Operit's own floating window can still be used through its native UI or external API, but the AIRS avatar is not injected into that window by this bridge.

## Build Without Local Flutter

The repository includes `.github/workflows/build-apk.yml`. Push this fork to a GitHub repository, then GitHub Actions will run on an x86_64 runner and:

```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --debug
```

The resulting `app-debug.apk` is uploaded as the `virtual-companion-operit-debug-apk` workflow artifact. You can also start the workflow manually from the Actions tab with `workflow_dispatch`.

The workflow does not use API keys, Operit tokens, or other secrets. Those remain local runtime settings and are not needed to compile the app.

## Local Verification

On a machine with Flutter installed, the same commands can be run locally:

```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --debug
```

The repository includes `test/operit_integration_test.dart`, which uses a mock HTTP client to verify URL normalization, Bearer authentication, health checks, first-chat creation, and continued-chat requests without contacting a real Operit device.

The ARM64 Linux environment used to prepare this fork does not contain `flutter` or `dart`, and the official Flutter Linux release currently publishes an x64 Dart SDK. Therefore the workflow is the primary build path for this device; local ARM64 installation was not attempted.


## Files Changed

- `lib/models/app_config.dart`
- `lib/services/ai_service.dart`
- `lib/app_controller.dart`
- `lib/services/background_task.dart`
- `lib/screens/settings_screen.dart`
- `lib/screens/chat_screen.dart`
- `android/app/src/main/AndroidManifest.xml`
- `test/operit_integration_test.dart`
