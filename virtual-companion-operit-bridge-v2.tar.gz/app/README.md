# 🐳 虚拟陪伴 (Virtual Companion)

> 一个可以接入 AI 大模型 API 的虚拟恋爱聊天软件。让 AI 扮演你的恋人与你聊天，内置角色库、创意工坊、日语语音、AI 主动消息等功能。

基于 **Flutter** 单代码库，一套源码同时编译出 **Windows `.exe`** 与 **Android `.apk`**。

---

## ✨ 功能

| 模块 | 说明 |
|------|------|
| 💬 恋爱聊天 | AI 扮演女友/恋人，傲娇、会吃醋、带「思维链心声」气泡，按角色人设驱动 |
| 🎭 创意工坊 · AIRS | 每个角色一个文件夹（`AIRS/<id>/`）：`character.json`（完整人设）+ `avatar.png`（头像）；可新增 / 导入 / 导出 / 切换 |
| 🤖 AI 三后端 | **DeepSeek 官方** + **OpenAI 兼容通用** + **本地 Ollama**（统一 OpenAI 协议） |
| 🧠 模型 / 思考 | 从接口拉取模型列表选择；可调**思考强度**（关闭/低/中/高，默认低） |
| 🗣️ 日语 TTS | 本地系统语音（flutter_tts）+ 在线 TTS（VOICEVOX / OpenAI TTS）双通道 |
| 🔔 AI 主动消息 | 应用打开闲置一段时间（可调，默认 20 分钟）AI 主动发消息；可开启**后台/锁屏**触发（WorkManager + 安卓通知） |
| 💖 好感系统 | 喂食 + 交流提升亲密度，驱动关系升级 |
| 🧠 记忆隔离 | 每个角色对话记忆独立、互不串，回来可续聊 |
| 🎨 界面 | 简约微信风，Windows 默认手机竖屏窗口 |

---

## 🚀 快速开始

### Windows（免安装）
解压 `dist/虚拟陪伴-Windows.zip`，双击 `whale_love.exe`。

### Android
安装 `dist/虚拟陪伴-Android.apk`。

### 从源码运行
```bash
flutter pub get
flutter run -d windows      # 桌面
flutter run -d <device>     # Android
```

### 首次配置三步
1. **填 API Key**：设置 → 默认 DeepSeek 官方接口，填 Key（或切 OpenAI 兼容 / 本地 Ollama）。
2. **测连接**：点「保存并应用设置」→「测试 AI 连接」。
3. **可选**：开语音、开 AI 主动消息。

---

## 🎭 AIRS 角色结构

每个角色是一个文件夹，文件夹名即角色 `id`：

```
AIRS/
  whale_dafeiyu/
    character.json   # 完整人设（20+ 字段，含 gender/性格/背景/口头禅/日语风味…）
    avatar.png       # 正方形头像（有人脸）
  senpai_tsundere/
    character.json
    avatar.png
```

- 内置角色首次运行自动同步到本机数据目录 `文档/whale_love/AIRS/`。
- 你在该目录新建文件夹放 `character.json`（+ 可选 `avatar.png`）重启即生效，**不会被覆盖或删除**。
- 完整字段规范见 [`docs/workshop-guide/character-schema.json`](docs/workshop-guide/character-schema.json)，多格式构建指南（README.md / guide.yaml / example-character.json）供人类与其他 AI 读取。

---

## 🔧 构建

```bash
# Windows exe
flutter build windows --release

# Android apk（需 JDK 17+，minSdk 24）
flutter build apk --release
```

> 注：Windows 插件构建若遇符号链接权限问题，需在系统开启「开发者模式」（或等价权限）。

---

## 🗂️ 数据存储
- 配置、角色库（`AIRS/`）、各角色聊天记录保存在系统应用文档目录 `whale_love/`。
- 角色卡可导出/导入，便于跨设备迁移。

---

## ⚠️ 说明
- 需有效 AI API Key 才能对话；Key 仅保存在本机。
- 本地 TTS 音质取决于系统语音包。
- 娱乐用途，角色设定基于社区二创。

## 📄 许可
MIT（本项目为个人娱乐项目，相关角色形象版权归原作者/社区所有）。
