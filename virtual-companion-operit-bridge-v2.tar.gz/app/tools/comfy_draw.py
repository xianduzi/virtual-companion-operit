#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
comfy_draw.py — 通过 ComfyUI API 生成本地图片（CPU 推理）。

用法:
  python comfy_draw.py "<提示词>" [--out <输出目录>] [--width W] [--height H]

工作流程:
  1. POST 一个 SD-Turbo 工作流到 ComfyUI /prompt
  2. 轮询 /history 直到任务完成
  3. 从 ComfyUI output 目录定位生成的 PNG
  4. 复制到指定输出目录（默认 E:\\deepseekgal\\output），打印最终路径

注意: 本脚本假设 ComfyUI 正在 http://127.0.0.1:8188 运行，
      checkpoint 名为 sd_turbo.safetensors，输出目录为 E:\\ComfyUI\\output。
"""
import argparse
import glob
import json
import os
import shutil
import sys
import time
import urllib.request
import uuid

COMFY_HOST = "http://127.0.0.1:8188"
CHECKPOINT = "sd_turbo.safetensors"
COMFY_OUTPUT_DIR = r"E:\ComfyUI\output"
DEFAULT_OUT_DIR = r"E:\deepseekgal\output"


def post_json(url, payload, timeout=60):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def build_workflow(prompt_text, width, height, seed):
    """构造 SD-Turbo 工作流（1 步出图）。"""
    return {
        "1": {"class_type": "CheckpointLoaderSimple", "inputs": {"ckpt_name": CHECKPOINT}},
        "2": {"class_type": "EmptyLatentImage", "inputs": {"width": width, "height": height, "batch_size": 1}},
        "3": {"class_type": "CLIPTextEncode", "inputs": {"text": prompt_text, "clip": ["1", 1]}},
        "4": {"class_type": "CLIPTextEncode", "inputs": {"text": "", "clip": ["1", 1]}},
        "5": {
            "class_type": "KSampler",
            "inputs": {
                "seed": seed,
                "steps": 1,
                "cfg": 1.0,
                "sampler_name": "euler",
                "scheduler": "simple",
                "denoise": 1.0,
                "model": ["1", 0],
                "positive": ["3", 0],
                "negative": ["4", 0],
                "latent_image": ["2", 0],
            },
        },
        "6": {"class_type": "VAEDecode", "inputs": {"samples": ["5", 0], "vae": ["1", 2]}},
        "7": {"class_type": "SaveImage", "inputs": {"filename_prefix": "dsh_draw", "images": ["6", 0]}},
    }


def latest_output_image(prefix="dsh_draw"):
    """返回 ComfyUI output 目录中前缀匹配的最新 PNG 路径。"""
    pat = os.path.join(COMFY_OUTPUT_DIR, f"{prefix}_*.png")
    files = sorted(glob.glob(pat), key=os.path.getmtime)
    return files[-1] if files else None


def main():
    ap = argparse.ArgumentParser(description="通过 ComfyUI 生成图片")
    ap.add_argument("prompt", help="生成提示词")
    ap.add_argument("--out", default=DEFAULT_OUT_DIR, help="输出目录")
    ap.add_argument("--width", type=int, default=512)
    ap.add_argument("--height", type=int, default=512)
    ap.add_argument("--seed", type=int, default=None)
    args = ap.parse_args()

    seed = args.seed if args.seed is not None else int(uuid.uuid4().int & 0xFFFFFFFF)

    # 1. 提交工作流
    workflow = build_workflow(args.prompt, args.width, args.height, seed)
    try:
        res = post_json(f"{COMFY_HOST}/prompt", {"prompt": workflow})
    except Exception as e:
        print(json.dumps({"ok": False, "error": f"提交失败: {e}"}, ensure_ascii=False))
        sys.exit(1)

    prompt_id = res.get("prompt_id")
    if not prompt_id:
        print(json.dumps({"ok": False, "error": f"未获取 prompt_id: {res}"}, ensure_ascii=False))
        sys.exit(1)

    # 2. 轮询直到完成
    deadline = time.time() + 600  # 最长等 10 分钟（CPU 慢）
    last_img = None
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(f"{COMFY_HOST}/history/{prompt_id}", timeout=10) as resp:
                hist = json.loads(resp.read().decode("utf-8"))
            entry = hist.get(prompt_id)
            if entry and entry.get("status", {}).get("completed"):
                break
        except Exception:
            pass
        time.sleep(3)

    # 3. 找最新图片
    last_img = latest_output_image()
    if not last_img:
        print(json.dumps({"ok": False, "error": "任务完成但未找到输出图片"}, ensure_ascii=False))
        sys.exit(1)

    # 4. 复制到输出目录
    os.makedirs(args.out, exist_ok=True)
    fname = os.path.basename(last_img)
    dest = os.path.join(args.out, fname)
    shutil.copy2(last_img, dest)

    print(json.dumps({"ok": True, "image": dest, "prompt_id": prompt_id, "seed": seed}, ensure_ascii=False))


if __name__ == "__main__":
    main()
