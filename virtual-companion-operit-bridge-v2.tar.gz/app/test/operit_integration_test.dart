import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:whale_love/data/characters.dart';
import 'package:whale_love/models/app_config.dart';
import 'package:whale_love/services/ai_service.dart';

void main() {
  final character = BuiltinCharacters.all.first;

  test('Operit URL accepts root, api, health, and chat endpoint forms', () {
    for (final input in [
      'http://192.168.1.23:8094',
      'http://192.168.1.23:8094/api',
      'http://192.168.1.23:8094/api/health',
      'http://192.168.1.23:8094/api/external-chat',
    ]) {
      final cfg = AppConfig(provider: 'operit', baseUrl: input);
      expect(cfg.operitBaseUrl, 'http://192.168.1.23:8094');
      expect(cfg.operitChatUrl,
          'http://192.168.1.23:8094/api/external-chat');
      expect(cfg.operitHealthUrl, 'http://192.168.1.23:8094/api/health');
    }
  });

  test('first Operit request creates a grouped chat and returns chat id', () async {
    late http.Request request;
    final client = MockClient((incoming) async {
      request = incoming;
      return http.Response(
        jsonEncode({
          'success': true,
          'chat_id': 'chat-001',
          'ai_response': '你好。',
        }),
        200,
        headers: {'content-type': 'application/json'},
      );
    });
    final service = AiService(client: client);

    final result = await service.chat(
      cfg: AppConfig(
        provider: 'operit',
        baseUrl: 'http://192.168.1.23:8094',
        apiKey: 'token',
      ),
      character: character,
      history: const [],
      userInput: '你好',
    );

    final body = jsonDecode(request.body) as Map<String, dynamic>;
    expect(request.url.toString(),
        'http://192.168.1.23:8094/api/external-chat');
    expect(request.headers['authorization'], 'Bearer token');
    expect(body['create_new_chat'], isTrue);
    expect(body['group'], 'virtual_companion_${character.id}');
    expect(body['chat_id'], isNull);
    expect(body['message'], contains('[角色设定]'));
    expect(result.text, '你好。');
    expect(result.chatId, 'chat-001');
    service.dispose();
  });

  test('continued Operit request only sends user text to existing chat',
      () async {
    late http.Request request;
    final client = MockClient((incoming) async {
      request = incoming;
      return http.Response(
        jsonEncode({
          'success': true,
          'chat_id': 'chat-001',
          'ai_response': '我记得。',
        }),
        200,
      );
    });
    final service = AiService(client: client);

    final result = await service.chat(
      cfg: AppConfig(
        provider: 'operit',
        baseUrl: 'http://operit.local:8094',
        apiKey: 'token',
      ),
      character: character,
      history: const [],
      userInput: '继续刚才的话题',
      operitChatId: 'chat-001',
    );

    final body = jsonDecode(request.body) as Map<String, dynamic>;
    expect(body['create_new_chat'], isFalse);
    expect(body['chat_id'], 'chat-001');
    expect(body['group'], isNull);
    expect(body['message'], '继续刚才的话题');
    expect(result.chatId, 'chat-001');
    service.dispose();
  });

  test('Operit health check does not send a chat request', () async {
    late http.Request request;
    final client = MockClient((incoming) async {
      request = incoming;
      return http.Response(
        jsonEncode({'status': 'ok', 'service_running': true}),
        200,
      );
    });
    final service = AiService(client: client);

    await service.testOperitConnection(AppConfig(
      provider: 'operit',
      baseUrl: 'http://operit.local:8094/api/external-chat',
      apiKey: 'token',
    ));

    expect(request.method, 'GET');
    expect(request.url.path, '/api/health');
    expect(request.headers['authorization'], 'Bearer token');
    service.dispose();
  });
}
