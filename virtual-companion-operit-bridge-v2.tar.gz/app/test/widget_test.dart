import 'package:flutter_test/flutter_test.dart';
import 'package:whale_love/models/message.dart';

void main() {
  test('splitThoughts 正确拆分正文与心声', () {
    const text = '别碰我啦！〔其实心跳好快…〕哼，笨、笨蛋。〔尾巴想给他〕';
    final parts = splitThoughts(text, 'assistant');
    expect(parts.length, 4);
    expect(parts[0].text, '别碰我啦！');
    expect(parts[0].isThought, false);
    expect(parts[1].text, '其实心跳好快…');
    expect(parts[1].isThought, true);
    expect(parts[2].text, '哼，笨、笨蛋。');
    expect(parts[2].isThought, false);
    expect(parts[3].text, '尾巴想给他');
    expect(parts[3].isThought, true);
  });

  test('无心声时返回单段', () {
    final parts = splitThoughts('普通一句话。', 'assistant');
    expect(parts.length, 1);
    expect(parts.first.isThought, false);
  });
}
